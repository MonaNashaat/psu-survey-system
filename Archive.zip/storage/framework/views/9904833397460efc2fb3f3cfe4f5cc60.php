<?php
    $pageTitle = 'إدارة الأقسام';
    $pageSubtitle = 'إضافة وعرض الأقسام وربطها بالكليات';
?>

<?php $__env->startSection('content'); ?>
    <div class="page-actions">
        <a href="<?php echo e(route('admin.academic.faculties.index')); ?>" class="btn btn-secondary">الكليات</a>
        <a href="<?php echo e(route('admin.academic.courses.index')); ?>" class="btn btn-secondary">المقررات</a>
        <a href="<?php echo e(route('admin.academic.offerings.index')); ?>" class="btn btn-secondary">المواد المسجلة</a>
    </div>

    <div class="grid-2">
        <div class="card">
            <div class="card-body">
                <h2 class="section-title">إضافة قسم جديد</h2>

                <form method="POST" action="<?php echo e(route('admin.academic.departments.store')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label class="form-label">الكلية</label>
                        <select name="faculty_id" required>
                            <option value="">اختر الكلية</option>
                            <?php $__currentLoopData = $faculties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faculty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($faculty->id); ?>" <?php echo e(old('faculty_id') == $faculty->id ? 'selected' : ''); ?>>
                                    <?php echo e($faculty->name_ar); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">اسم القسم بالعربية</label>
                        <input type="text" name="name_ar" value="<?php echo e(old('name_ar')); ?>" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">اسم القسم بالإنجليزية</label>
                        <input type="text" name="name_en" value="<?php echo e(old('name_en')); ?>">
                    </div>

                    <button type="submit" class="btn btn-primary">إضافة القسم</button>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <h2 class="section-title">ملخص سريع</h2>

                <div class="grid-2">
                    <div class="card stats-card">
                        <div class="stats-title">عدد الأقسام</div>
                        <div class="stats-value"><?php echo e($departments->count()); ?></div>
                    </div>

                    <div class="card stats-card">
                        <div class="stats-title">عدد الكليات</div>
                        <div class="stats-value"><?php echo e($faculties->count()); ?></div>
                    </div>
                </div>

                <div style="height: 12px;"></div>

                <div class="card stats-card">
                    <div class="stats-title">آخر قسم مضاف</div>
                    <div class="stats-value" style="font-size:18px;">
                        <?php echo e($departments->first()?->name_ar ?? '—'); ?>

                    </div>
                    <div class="stats-note">
                        <?php echo e($departments->first()?->faculty?->name_ar ?? ''); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <div style="height: 16px;"></div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>الكلية</th>
                    <th>اسم القسم بالعربية</th>
                    <th>اسم القسم بالإنجليزية</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($department->id); ?></td>
                        <td><?php echo e($department->faculty?->name_ar ?? '—'); ?></td>
                        <td><?php echo e($department->name_ar); ?></td>
                        <td><?php echo e($department->name_en ?: '—'); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4">
                            <div class="empty-state">لا توجد أقسام حتى الآن</div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/monanashaat/Projects/university-survey/resources/views/admin/academic/departments/index.blade.php ENDPATH**/ ?>