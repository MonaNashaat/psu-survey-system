<?php
    $pageTitle = 'إدارة المقررات';
    $pageSubtitle = 'إضافة وعرض المقررات وربطها بالأقسام';
?>

<?php $__env->startSection('content'); ?>
    <div class="page-actions">
        <a href="<?php echo e(route('admin.academic.faculties.index')); ?>" class="btn btn-secondary">الكليات</a>
        <a href="<?php echo e(route('admin.academic.departments.index')); ?>" class="btn btn-secondary">الأقسام</a>
        <a href="<?php echo e(route('admin.academic.offerings.index')); ?>" class="btn btn-secondary">المواد المسجلة</a>
    </div>

    <div class="grid-2">
        <div class="card">
            <div class="card-body">
                <h2 class="section-title">إضافة مقرر جديد</h2>

                <form method="POST" action="<?php echo e(route('admin.academic.courses.store')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label class="form-label">القسم</label>
                        <select name="department_id" required>
                            <option value="">اختر القسم</option>
                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($department->id); ?>" <?php echo e(old('department_id') == $department->id ? 'selected' : ''); ?>>
                                    <?php echo e($department->name_ar); ?> - <?php echo e($department->faculty?->name_ar); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">كود المقرر</label>
                        <input type="text" name="code" value="<?php echo e(old('code')); ?>">
                    </div>

                    <div class="form-group">
                        <label class="form-label">اسم المقرر بالعربية</label>
                        <input type="text" name="name_ar" value="<?php echo e(old('name_ar')); ?>" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">اسم المقرر بالإنجليزية</label>
                        <input type="text" name="name_en" value="<?php echo e(old('name_en')); ?>">
                    </div>

                    <button type="submit" class="btn btn-primary">إضافة المقرر</button>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <h2 class="section-title">ملخص سريع</h2>

                <div class="grid-2">
                    <div class="card stats-card">
                        <div class="stats-title">عدد المقررات</div>
                        <div class="stats-value"><?php echo e($courses->count()); ?></div>
                    </div>

                    <div class="card stats-card">
                        <div class="stats-title">عدد الأقسام</div>
                        <div class="stats-value"><?php echo e($departments->count()); ?></div>
                    </div>
                </div>

                <div style="height: 12px;"></div>

                <div class="card stats-card">
                    <div class="stats-title">آخر مقرر مضاف</div>
                    <div class="stats-value" style="font-size:18px;">
                        <?php echo e($courses->first()?->name_ar ?? '—'); ?>

                    </div>
                    <div class="stats-note">
                        <?php echo e($courses->first()?->code ?? ''); ?>

                        <?php if($courses->first()?->department?->name_ar): ?>
                            | <?php echo e($courses->first()?->department?->name_ar); ?>

                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div style="height: 16px;"></div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>الكلية</th>
                    <th>القسم</th>
                    <th>كود المقرر</th>
                    <th>اسم المقرر بالعربية</th>
                    <th>اسم المقرر بالإنجليزية</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($course->id); ?></td>
                        <td><?php echo e($course->department?->faculty?->name_ar ?? '—'); ?></td>
                        <td><?php echo e($course->department?->name_ar ?? '—'); ?></td>
                        <td><?php echo e($course->code ?: '—'); ?></td>
                        <td><?php echo e($course->name_ar); ?></td>
                        <td><?php echo e($course->name_en ?: '—'); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6">
                            <div class="empty-state">لا توجد مقررات حتى الآن</div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/monanashaat/Projects/university-survey/resources/views/admin/academic/courses/index.blade.php ENDPATH**/ ?>