<?php
    $pageTitle = 'تعديل قالب';
    $pageSubtitle = 'تعديل قالب استبيان موجود وإدارة محاوره وأسئلته';
?>

<?php $__env->startSection('content'); ?>
    <?php
        $standaloneQuestion = $template->questions->firstWhere('survey_template_section_id', null);
    ?>

    <div class="page-actions">
        <a href="<?php echo e(route('admin.templates.index')); ?>" class="btn btn-secondary">الرجوع إلى القوالب</a>
    </div>

    <div class="card">
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('admin.templates.update', $template->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="grid-2">
                    <div class="form-group">
                        <label class="form-label">اسم القالب</label>
                        <input type="text" name="name" value="<?php echo e(old('name', $template->name)); ?>">
                    </div>

                    <div class="checkbox-row" style="margin-top: 32px;">
                        <input type="checkbox" id="is_active" name="is_active" <?php echo e(old('is_active', $template->is_active) ? 'checked' : ''); ?>>
                        <label for="is_active" style="margin:0;">تفعيل القالب</label>
                    </div>
                </div>

                <div class="grid-2">
                    <?php if(auth()->user()->isAdmin()): ?>
                        <div class="form-group">
                            <label class="form-label">تصنيف القالب</label>
                            <select name="template_type" id="template_type">
                                <option value="institutional" <?php echo e(old('template_type', $template->template_type) == 'institutional' ? 'selected' : ''); ?>>قالب مؤسسي</option>
                                <option value="department" <?php echo e(old('template_type', $template->template_type) == 'department' ? 'selected' : ''); ?>>قالب خاص بالقسم</option>
                            </select>
                        </div>

                        <div class="form-group" id="department-wrapper">
                            <label class="form-label">القسم</label>
                            <select name="department_id">
                                <option value="">اختر القسم</option>
                                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($department->id); ?>"
                                        <?php echo e(old('department_id', $template->department_id) == $department->id ? 'selected' : ''); ?>>
                                        <?php echo e($department->name_ar); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    <?php else: ?>
                        <input type="hidden" name="template_type" value="department">
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label class="form-label">وصف القالب</label>
                    <textarea name="description"><?php echo e(old('description', $template->description)); ?></textarea>
                </div>

                <hr style="margin:24px 0; border:none; border-top:1px solid #e4e8f0;">

                <div class="page-actions" style="justify-content:space-between; align-items:center;">
                    <h2 class="section-title" style="margin:0;">المحاور والأسئلة</h2>
                    <button type="button" class="btn btn-primary" onclick="addSection()">إضافة محور</button>
                </div>

                <div id="sections-wrapper"></div>

                <hr style="margin:24px 0; border:none; border-top:1px solid #e4e8f0;">

                <div class="form-group">
                    <label class="form-label">سؤال التعليقات الإضافية</label>
                    <input type="text" name="comments_question" value="<?php echo e(old('comments_question', $standaloneQuestion?->question_text ?? 'تعليقات أخرى')); ?>">
                </div>

                <div class="page-actions">
                    <button type="submit" class="btn btn-primary">حفظ التعديلات</button>
                    <a href="<?php echo e(route('admin.templates.index')); ?>" class="btn btn-secondary">إلغاء</a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .section-box,
    .question-box {
        border: 1px solid #e4e8f0;
        border-radius: 16px;
        padding: 16px;
        margin-bottom: 16px;
        background: #fafbff;
    }

    .section-title-inline {
        margin-bottom: 12px;
        font-size: 18px;
        font-weight: 800;
        color: #28335f;
    }

    .option-input {
        margin-bottom: 8px;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    let sectionIndex = 0;

    function removeElement(id) {
        const el = document.getElementById(id);
        if (el) el.remove();
    }

    function addSection(title = '', questions = []) {
        const wrapper = document.getElementById('sections-wrapper');
        const currentSectionIndex = sectionIndex;

        const html = `
            <div class="section-box" id="section-${currentSectionIndex}">
                <div class="section-title-inline">محور</div>

                <div class="form-group">
                    <label class="form-label">عنوان المحور</label>
                    <input type="text" name="sections[${currentSectionIndex}][title]" value="${escapeHtml(title)}">
                </div>

                <div id="questions-wrapper-${currentSectionIndex}"></div>

                <div class="page-actions">
                    <button type="button" class="btn btn-primary" onclick="addQuestion(${currentSectionIndex})">إضافة سؤال</button>
                    <button type="button" class="btn btn-danger" onclick="removeElement('section-${currentSectionIndex}')">حذف المحور</button>
                </div>
            </div>
        `;

        wrapper.insertAdjacentHTML('beforeend', html);

        questions.forEach(question => {
            addQuestion(
                currentSectionIndex,
                question.question_text,
                question.type,
                question.is_required,
                question.options || []
            );
        });

        sectionIndex++;
    }

    function addQuestion(sectionIdx, questionText = '', questionType = 'scale', isRequired = true, options = []) {
        const wrapper = document.getElementById(`questions-wrapper-${sectionIdx}`);
        const questionCount = wrapper.querySelectorAll('.question-box').length;

        let optionsHtml = '';

        if (options.length === 0 && (questionType === 'scale' || questionType === 'mcq')) {
            options = questionType === 'scale'
                ? ['غير موافق بشدة', 'غير موافق', 'محايد', 'أوافق', 'أوافق بشدة']
                : ['', ''];
        }

        options.forEach(option => {
            optionsHtml += `
                <div class="option-input">
                    <input type="text" name="sections[${sectionIdx}][questions][${questionCount}][options][]" value="${escapeHtml(option)}">
                </div>
            `;
        });

        const html = `
            <div class="question-box" id="section-${sectionIdx}-question-${questionCount}">
                <div class="form-group">
                    <label class="form-label">نص السؤال</label>
                    <textarea name="sections[${sectionIdx}][questions][${questionCount}][question_text]">${escapeHtml(questionText)}</textarea>
                </div>

                <div class="form-group">
                    <label class="form-label">نوع السؤال</label>
                    <select name="sections[${sectionIdx}][questions][${questionCount}][type]" onchange="toggleOptions(this, ${sectionIdx}, ${questionCount})">
                        <option value="scale" ${questionType === 'scale' ? 'selected' : ''}>تقييم 1-5</option>
                        <option value="mcq" ${questionType === 'mcq' ? 'selected' : ''}>اختيار من متعدد</option>
                        <option value="text" ${questionType === 'text' ? 'selected' : ''}>نص مفتوح</option>
                    </select>
                </div>

                <div class="checkbox-row">
                    <input type="checkbox" id="required-${sectionIdx}-${questionCount}" name="sections[${sectionIdx}][questions][${questionCount}][is_required]" ${isRequired ? 'checked' : ''}>
                    <label for="required-${sectionIdx}-${questionCount}" style="margin:0;">سؤال إجباري</label>
                </div>

                <div class="form-group options-box" id="options-box-${sectionIdx}-${questionCount}" style="${questionType === 'text' ? 'display:none;' : ''}">
                    <label class="form-label">الخيارات</label>
                    ${optionsHtml}
                    <button type="button" class="btn btn-secondary" onclick="addOption(${sectionIdx}, ${questionCount})">إضافة اختيار</button>
                </div>

                <div class="page-actions">
                    <button type="button" class="btn btn-danger" onclick="removeElement('section-${sectionIdx}-question-${questionCount}')">حذف السؤال</button>
                </div>
            </div>
        `;

        wrapper.insertAdjacentHTML('beforeend', html);
    }

    function addOption(sectionIdx, questionIdx) {
        const box = document.getElementById(`options-box-${sectionIdx}-${questionIdx}`);
        const btn = box.querySelector('button');
        const div = document.createElement('div');

        div.className = 'option-input';
        div.innerHTML = `<input type="text" name="sections[${sectionIdx}][questions][${questionIdx}][options][]" value="">`;

        box.insertBefore(div, btn);
    }

    function toggleOptions(selectEl, sectionIdx, questionIdx) {
        const box = document.getElementById(`options-box-${sectionIdx}-${questionIdx}`);
        box.style.display = selectEl.value === 'text' ? 'none' : 'block';
    }

    function escapeHtml(text) {
        if (text === null || text === undefined) return '';
        return String(text)
            .replace(/&/g, '&amp;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
    }

    const existingSections = [
        <?php $__currentLoopData = $template->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            {
                title: <?php echo json_encode($section->title, 15, 512) ?>,
                questions: [
                    <?php $__currentLoopData = $section->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        {
                            question_text: <?php echo json_encode($question->question_text, 15, 512) ?>,
                            type: <?php echo json_encode($question->type, 15, 512) ?>,
                            is_required: <?php echo e($question->is_required ? 'true' : 'false'); ?>,
                            options: [
                                <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo json_encode($option->option_text, 15, 512) ?>,
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            ]
                        },
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ]
            },
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    ];

    if (existingSections.length) {
        existingSections.forEach(section => addSection(section.title, section.questions));
    } else {
        addSection();
    }

    const templateTypeSelect = document.getElementById('template_type');
    const departmentWrapper = document.getElementById('department-wrapper');

    function toggleDepartmentField() {
        if (!templateTypeSelect || !departmentWrapper) return;
        departmentWrapper.style.display = templateTypeSelect.value === 'department' ? 'block' : 'none';
    }

    if (templateTypeSelect) {
        templateTypeSelect.addEventListener('change', toggleDepartmentField);
        toggleDepartmentField();
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/monanashaat/Projects/university-survey/resources/views/admin/templates/edit.blade.php ENDPATH**/ ?>