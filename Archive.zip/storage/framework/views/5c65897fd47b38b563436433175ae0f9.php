<?php
    $pageTitle = 'تعديل الاستبيان';
    $pageSubtitle = 'تعديل بيانات الاستبيان والمحاور والأسئلة';
?>

<?php $__env->startSection('content'); ?>
    <?php
        $standaloneQuestion = $survey->questions->firstWhere('survey_section_id', null);

        $selectedOffering = $survey->courseOffering;
        $selectedCourse = $selectedOffering?->course;
        $selectedDepartment = $selectedCourse?->department;
        $selectedFaculty = $selectedDepartment?->faculty;

        $surveyScope = old('survey_scope', $survey->course_offering_id ? 'course' : 'general');

        $departmentsJson = $departments->map(function ($department) {
            return [
                'id' => $department->id,
                'name_ar' => $department->name_ar,
                'faculty_id' => $department->faculty_id,
            ];
        })->values();

        $coursesJson = $courses->map(function ($course) {
            return [
                'id' => $course->id,
                'name_ar' => $course->name_ar,
                'code' => $course->code,
                'department_id' => $course->department_id,
            ];
        })->values();

        $offeringsJson = $courseOfferings->map(function ($offering) {
            return [
                'id' => $offering->id,
                'course_id' => $offering->course_id,
                'academic_year' => $offering->academic_year,
                'semester' => $offering->semester,
                'level' => $offering->level,
                'instructor_name' => $offering->instructor_name,
                'assistant_name' => $offering->assistant_name,
            ];
        })->values();
    ?>

    <div class="page-actions">
        <a href="<?php echo e(route('admin.surveys.show', $survey->id)); ?>" class="btn btn-secondary">عرض الاستبيان</a>
        <a href="<?php echo e(route('admin.surveys.index')); ?>" class="btn btn-secondary">الرجوع إلى الاستبيانات</a>
    </div>

    <div class="card">
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('admin.surveys.update', $survey->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="grid-2">
                    <div class="form-group">
                        <label class="form-label">عنوان الاستبيان</label>
                        <input type="text" name="title" value="<?php echo e(old('title', $survey->title)); ?>">
                    </div>

                    <div class="form-group">
                        <label class="form-label">نوع الاستبيان</label>
                        <select name="survey_scope" id="survey_scope">
                            <option value="general" <?php echo e($surveyScope === 'general' ? 'selected' : ''); ?>>استبيان عام</option>
                            <option value="course" <?php echo e($surveyScope === 'course' ? 'selected' : ''); ?>>استبيان مرتبط بمادة</option>
                        </select>
                    </div>
                </div>

                <div id="course-offering-wrapper">
                    <div class="grid-2">
                        <div class="form-group">
                            <label class="form-label">الكلية</label>
                            <select id="faculty_id">
                                <option value="">اختر الكلية</option>
                                <?php $__currentLoopData = $faculties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faculty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($faculty->id); ?>"
                                        <?php echo e(old('faculty_id', $selectedFaculty?->id) == $faculty->id ? 'selected' : ''); ?>>
                                        <?php echo e($faculty->name_ar); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label">القسم</label>
                            <select id="department_id">
                                <option value="">اختر القسم</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label">المقرر</label>
                            <select id="course_id">
                                <option value="">اختر المقرر</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label">المادة المسجلة</label>
                            <select name="course_offering_id" id="course_offering_id">
                                <option value="">اختر المادة المسجلة</option>
                            </select>
                        </div>
                    </div>

                    <div id="offering-preview" class="card" style="display:none; margin-bottom:16px; background:#f8f9ff; border-color:#d9def7;">
                        <div class="card-body" id="offering-preview-content"></div>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">وصف الاستبيان</label>
                    <textarea name="description"><?php echo e(old('description', $survey->description)); ?></textarea>
                </div>

                <div class="checkbox-row">
                    <input type="checkbox" id="is_active" name="is_active" <?php echo e(old('is_active', $survey->is_active) ? 'checked' : ''); ?>>
                    <label for="is_active" style="margin:0;">تفعيل الاستبيان</label>
                </div>

                <div class="checkbox-row">
                    <input type="checkbox" id="allow_multiple_submissions" name="allow_multiple_submissions" <?php echo e(old('allow_multiple_submissions', $survey->allow_multiple_submissions) ? 'checked' : ''); ?>>
                    <label for="allow_multiple_submissions" style="margin:0;">السماح بأكثر من رد من نفس الجهاز</label>
                </div>

                <hr style="margin:24px 0; border:none; border-top:1px solid #e4e8f0;">

                <div class="page-actions" style="justify-content:space-between; align-items:center;">
                    <h2 class="section-title" style="margin:0;">المحاور والأسئلة</h2>
                    <button type="button" class="btn btn-primary" onclick="addSection()">إضافة محور</button>
                </div>

                <div id="sections-wrapper"></div>

                <hr style="margin:24px 0; border:none; border-top:1px solid #e4e8f0;">

                <div class="form-group">
                    <label class="form-label">سؤال التعليقات الإضافية</label>
                    <input type="text" name="comments_question" value="<?php echo e(old('comments_question', $standaloneQuestion?->question_text ?? 'تعليقات أخرى')); ?>">
                </div>

                <div class="page-actions">
                    <button type="submit" class="btn btn-primary">حفظ التعديلات</button>
                    <a href="<?php echo e(route('admin.surveys.show', $survey->id)); ?>" class="btn btn-secondary">إلغاء</a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .section-box,
    .question-box {
        border: 1px solid #e4e8f0;
        border-radius: 16px;
        padding: 16px;
        margin-bottom: 16px;
        background: #fafbff;
    }

    .section-title-inline {
        margin-bottom: 12px;
        font-size: 18px;
        font-weight: 800;
        color: #28335f;
    }

    .option-input {
        margin-bottom: 8px;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    let sectionIndex = 0;

    function removeElement(id) {
        const el = document.getElementById(id);
        if (el) el.remove();
    }

    function addSection(title = '', questions = []) {
        const wrapper = document.getElementById('sections-wrapper');
        const currentSectionIndex = sectionIndex;

        const html = `
            <div class="section-box" id="section-${currentSectionIndex}">
                <div class="section-title-inline">محور</div>

                <div class="form-group">
                    <label class="form-label">عنوان المحور</label>
                    <input type="text" name="sections[${currentSectionIndex}][title]" value="${escapeHtml(title)}">
                </div>

                <div id="questions-wrapper-${currentSectionIndex}"></div>

                <div class="page-actions">
                    <button type="button" class="btn btn-primary" onclick="addQuestion(${currentSectionIndex})">إضافة سؤال</button>
                    <button type="button" class="btn btn-danger" onclick="removeElement('section-${currentSectionIndex}')">حذف المحور</button>
                </div>
            </div>
        `;

        wrapper.insertAdjacentHTML('beforeend', html);

        questions.forEach(question => {
            addQuestion(
                currentSectionIndex,
                question.question_text,
                question.type,
                question.is_required,
                question.options || []
            );
        });

        sectionIndex++;
    }

    function addQuestion(sectionIdx, questionText = '', questionType = 'scale', isRequired = true, options = []) {
        const wrapper = document.getElementById(`questions-wrapper-${sectionIdx}`);
        const questionCount = wrapper.querySelectorAll('.question-box').length;

        let optionsHtml = '';

        if (options.length === 0 && (questionType === 'scale' || questionType === 'mcq')) {
            options = questionType === 'scale'
                ? ['غير موافق بشدة', 'غير موافق', 'محايد', 'أوافق', 'أوافق بشدة']
                : ['', ''];
        }

        options.forEach(option => {
            optionsHtml += `
                <div class="option-input">
                    <input type="text" name="sections[${sectionIdx}][questions][${questionCount}][options][]" value="${escapeHtml(option)}">
                </div>
            `;
        });

        const html = `
            <div class="question-box" id="section-${sectionIdx}-question-${questionCount}">
                <div class="form-group">
                    <label class="form-label">نص السؤال</label>
                    <textarea name="sections[${sectionIdx}][questions][${questionCount}][question_text]">${escapeHtml(questionText)}</textarea>
                </div>

                <div class="form-group">
                    <label class="form-label">نوع السؤال</label>
                    <select name="sections[${sectionIdx}][questions][${questionCount}][type]" onchange="toggleOptions(this, ${sectionIdx}, ${questionCount})">
                        <option value="scale" ${questionType === 'scale' ? 'selected' : ''}>تقييم 1-5</option>
                        <option value="mcq" ${questionType === 'mcq' ? 'selected' : ''}>اختيار من متعدد</option>
                        <option value="text" ${questionType === 'text' ? 'selected' : ''}>نص مفتوح</option>
                    </select>
                </div>

                <div class="checkbox-row">
                    <input type="checkbox" id="required-${sectionIdx}-${questionCount}" name="sections[${sectionIdx}][questions][${questionCount}][is_required]" ${isRequired ? 'checked' : ''}>
                    <label for="required-${sectionIdx}-${questionCount}" style="margin:0;">سؤال إجباري</label>
                </div>

                <div class="form-group options-box" id="options-box-${sectionIdx}-${questionCount}" style="${questionType === 'text' ? 'display:none;' : ''}">
                    <label class="form-label">الخيارات</label>
                    ${optionsHtml}
                    <button type="button" class="btn btn-secondary" onclick="addOption(${sectionIdx}, ${questionCount})">إضافة اختيار</button>
                </div>

                <div class="page-actions">
                    <button type="button" class="btn btn-danger" onclick="removeElement('section-${sectionIdx}-question-${questionCount}')">حذف السؤال</button>
                </div>
            </div>
        `;

        wrapper.insertAdjacentHTML('beforeend', html);
    }

    function addOption(sectionIdx, questionIdx) {
        const box = document.getElementById(`options-box-${sectionIdx}-${questionIdx}`);
        const btn = box.querySelector('button');
        const div = document.createElement('div');
        div.className = 'option-input';
        div.innerHTML = `<input type="text" name="sections[${sectionIdx}][questions][${questionIdx}][options][]" value="">`;
        box.insertBefore(div, btn);
    }

    function toggleOptions(selectEl, sectionIdx, questionIdx) {
        const box = document.getElementById(`options-box-${sectionIdx}-${questionIdx}`);
        box.style.display = selectEl.value === 'text' ? 'none' : 'block';
    }

    function escapeHtml(text) {
        if (text === null || text === undefined) return '';
        return String(text)
            .replace(/&/g, '&amp;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
    }

    const existingSections = [
        <?php $__currentLoopData = $survey->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            {
                title: <?php echo json_encode($section->title, 15, 512) ?>,
                questions: [
                    <?php $__currentLoopData = $section->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        {
                            question_text: <?php echo json_encode($question->question_text, 15, 512) ?>,
                            type: <?php echo json_encode($question->type, 15, 512) ?>,
                            is_required: <?php echo e($question->is_required ? 'true' : 'false'); ?>,
                            options: [
                                <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo json_encode($option->option_text, 15, 512) ?>,
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            ]
                        },
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ]
            },
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    ];

    if (existingSections.length) {
        existingSections.forEach(section => addSection(section.title, section.questions));
    } else {
        addSection();
    }
</script>

<script>
    const departmentsData = <?php echo json_encode($departmentsJson, 15, 512) ?>;
    const coursesData = <?php echo json_encode($coursesJson, 15, 512) ?>;
    const offeringsData = <?php echo json_encode($offeringsJson, 15, 512) ?>;

    const semesterLabels = {
        first: 'الفصل الدراسي الأول',
        second: 'الفصل الدراسي الثاني',
        summer: 'الفصل الصيفي',
    };

    const facultySelect = document.getElementById('faculty_id');
    const departmentSelect = document.getElementById('department_id');
    const courseSelect = document.getElementById('course_id');
    const offeringSelect = document.getElementById('course_offering_id');
    const offeringPreview = document.getElementById('offering-preview');
    const offeringPreviewContent = document.getElementById('offering-preview-content');
    const surveyScopeSelect = document.getElementById('survey_scope');
    const courseOfferingWrapper = document.getElementById('course-offering-wrapper');

    const selectedDepartmentId = <?php echo json_encode(old('department_id', $selectedDepartment?->id), 512) ?>;
    const selectedCourseId = <?php echo json_encode(old('course_id', $selectedCourse?->id), 512) ?>;
    const selectedOfferingId = <?php echo json_encode(old('course_offering_id', $survey->course_offering_id), 512) ?>;

    function resetSelect(select, placeholder) {
        select.innerHTML = `<option value="">${placeholder}</option>`;
    }

    function populateDepartments(selected = null) {
        resetSelect(departmentSelect, 'اختر القسم');
        resetSelect(courseSelect, 'اختر المقرر');
        resetSelect(offeringSelect, 'اختر المادة المسجلة');
        offeringPreview.style.display = 'none';
        offeringPreviewContent.innerHTML = '';

        const facultyId = facultySelect.value;
        if (!facultyId) return;

        const filteredDepartments = departmentsData.filter(
            department => String(department.faculty_id) === String(facultyId)
        );

        filteredDepartments.forEach(department => {
            const option = document.createElement('option');
            option.value = department.id;
            option.textContent = department.name_ar;

            if (selected && String(selected) === String(department.id)) {
                option.selected = true;
            }

            departmentSelect.appendChild(option);
        });
    }

    function populateCourses(selected = null) {
        resetSelect(courseSelect, 'اختر المقرر');
        resetSelect(offeringSelect, 'اختر المادة المسجلة');
        offeringPreview.style.display = 'none';
        offeringPreviewContent.innerHTML = '';

        const departmentId = departmentSelect.value;
        if (!departmentId) return;

        const filteredCourses = coursesData.filter(
            course => String(course.department_id) === String(departmentId)
        );

        filteredCourses.forEach(course => {
            const option = document.createElement('option');
            option.value = course.id;
            option.textContent = `${course.name_ar}${course.code ? ' - ' + course.code : ''}`;

            if (selected && String(selected) === String(course.id)) {
                option.selected = true;
            }

            courseSelect.appendChild(option);
        });
    }

    function populateOfferings(selected = null) {
        resetSelect(offeringSelect, 'اختر المادة المسجلة');
        offeringPreview.style.display = 'none';
        offeringPreviewContent.innerHTML = '';

        const courseId = courseSelect.value;
        if (!courseId) return;

        const filteredOfferings = offeringsData.filter(
            offering => String(offering.course_id) === String(courseId)
        );

        filteredOfferings.forEach(offering => {
            const option = document.createElement('option');
            option.value = offering.id;
            option.textContent = `${offering.academic_year} - ${semesterLabels[offering.semester] ?? offering.semester} - ${offering.level}`;

            if (selected && String(selected) === String(offering.id)) {
                option.selected = true;
            }

            offeringSelect.appendChild(option);
        });

        showOfferingPreview();
    }

    function showOfferingPreview() {
        offeringPreview.style.display = 'none';
        offeringPreviewContent.innerHTML = '';

        const selectedId = offeringSelect.value;
        if (!selectedId) return;

        const selectedOffering = offeringsData.find(
            offering => String(offering.id) === String(selectedId)
        );

        if (!selectedOffering) return;

        offeringPreviewContent.innerHTML = `
            <strong>بيانات المادة المسجلة:</strong><br>
            العام الدراسي: ${selectedOffering.academic_year}<br>
            الفصل الدراسي: ${semesterLabels[selectedOffering.semester] ?? selectedOffering.semester}<br>
            الفرقة: ${selectedOffering.level}<br>
            القائم على التدريس: ${selectedOffering.instructor_name ?? '-'}<br>
            الهيئة المعاونة: ${selectedOffering.assistant_name ?? '-'}
        `;
        offeringPreview.style.display = 'block';
    }

    function toggleSurveyScope() {
        if (surveyScopeSelect.value === 'course') {
            courseOfferingWrapper.style.display = 'block';
        } else {
            courseOfferingWrapper.style.display = 'none';

            facultySelect.value = '';
            resetSelect(departmentSelect, 'اختر القسم');
            resetSelect(courseSelect, 'اختر المقرر');
            resetSelect(offeringSelect, 'اختر المادة المسجلة');
            offeringPreview.style.display = 'none';
            offeringPreviewContent.innerHTML = '';
        }
    }

    facultySelect.addEventListener('change', () => populateDepartments());
    departmentSelect.addEventListener('change', () => populateCourses());
    courseSelect.addEventListener('change', () => populateOfferings());
    offeringSelect.addEventListener('change', showOfferingPreview);
    surveyScopeSelect.addEventListener('change', toggleSurveyScope);

    toggleSurveyScope();

    if (surveyScopeSelect.value === 'course' && facultySelect.value) {
        populateDepartments(selectedDepartmentId);
        populateCourses(selectedCourseId);
        populateOfferings(selectedOfferingId);
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/monanashaat/Projects/university-survey/resources/views/admin/surveys/edit.blade.php ENDPATH**/ ?>