<?php
    $pageTitle = 'إدارة المواد المسجلة';
    $pageSubtitle = 'إضافة وعرض المواد المسجلة المرتبطة بالمقررات';
?>

<?php $__env->startSection('content'); ?>
    <?php
        $semesterLabels = [
            'first' => 'الفصل الدراسي الأول',
            'second' => 'الفصل الدراسي الثاني',
            'summer' => 'الفصل الصيفي',
        ];
    ?>

    <div class="page-actions">
        <a href="<?php echo e(route('admin.academic.faculties.index')); ?>" class="btn btn-secondary">الكليات</a>
        <a href="<?php echo e(route('admin.academic.departments.index')); ?>" class="btn btn-secondary">الأقسام</a>
        <a href="<?php echo e(route('admin.academic.courses.index')); ?>" class="btn btn-secondary">المقررات</a>
    </div>

    <div class="grid-2">
        <div class="card">
            <div class="card-body">
                <h2 class="section-title">إضافة مادة مسجلة جديدة</h2>

                <form method="POST" action="<?php echo e(route('admin.academic.offerings.store')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label class="form-label">المقرر</label>
                        <select name="course_id" required>
                            <option value="">اختر المقرر</option>
                            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($course->id); ?>" <?php echo e(old('course_id') == $course->id ? 'selected' : ''); ?>>
                                    <?php echo e($course->name_ar); ?><?php echo e($course->code ? ' - ' . $course->code : ''); ?> - <?php echo e($course->department?->name_ar); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">العام الدراسي</label>
                        <input type="text" name="academic_year" value="<?php echo e(old('academic_year')); ?>" placeholder="مثال: 2024-2025" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">الفصل الدراسي</label>
                        <select name="semester" required>
                            <option value="">اختر الفصل الدراسي</option>
                            <option value="first" <?php echo e(old('semester') == 'first' ? 'selected' : ''); ?>>الفصل الدراسي الأول</option>
                            <option value="second" <?php echo e(old('semester') == 'second' ? 'selected' : ''); ?>>الفصل الدراسي الثاني</option>
                            <option value="summer" <?php echo e(old('semester') == 'summer' ? 'selected' : ''); ?>>الفصل الصيفي</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">الفرقة</label>
                        <input type="text" name="level" value="<?php echo e(old('level')); ?>" placeholder="مثال: الفرقة الثانية" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">القائم على التدريس</label>
                        <input type="text" name="instructor_name" value="<?php echo e(old('instructor_name')); ?>">
                    </div>

                    <div class="form-group">
                        <label class="form-label">الهيئة المعاونة</label>
                        <input type="text" name="assistant_name" value="<?php echo e(old('assistant_name')); ?>">
                    </div>

                    <button type="submit" class="btn btn-primary">إضافة المادة</button>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <h2 class="section-title">ملخص سريع</h2>

                <div class="grid-2">
                    <div class="card stats-card">
                        <div class="stats-title">عدد المواد المسجلة</div>
                        <div class="stats-value"><?php echo e($offerings->count()); ?></div>
                    </div>

                    <div class="card stats-card">
                        <div class="stats-title">عدد المقررات</div>
                        <div class="stats-value"><?php echo e($courses->count()); ?></div>
                    </div>
                </div>

                <div style="height: 12px;"></div>

                <div class="card stats-card">
                    <div class="stats-title">آخر مادة مضافة</div>
                    <div class="stats-value" style="font-size:18px;">
                        <?php echo e($offerings->first()?->course?->name_ar ?? '—'); ?>

                    </div>
                    <div class="stats-note">
                        <?php echo e($offerings->first()?->academic_year ?? ''); ?>

                        <?php if($offerings->first()?->semester): ?>
                            | <?php echo e($semesterLabels[$offerings->first()?->semester] ?? $offerings->first()?->semester); ?>

                        <?php endif; ?>
                        <?php if($offerings->first()?->level): ?>
                            | <?php echo e($offerings->first()?->level); ?>

                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div style="height: 16px;"></div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>الكلية</th>
                    <th>القسم</th>
                    <th>المقرر</th>
                    <th>الكود</th>
                    <th>العام الدراسي</th>
                    <th>الفصل الدراسي</th>
                    <th>الفرقة</th>
                    <th>القائم على التدريس</th>
                    <th>الهيئة المعاونة</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $offerings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offering): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($offering->id); ?></td>
                        <td><?php echo e($offering->course?->department?->faculty?->name_ar ?? '—'); ?></td>
                        <td><?php echo e($offering->course?->department?->name_ar ?? '—'); ?></td>
                        <td><?php echo e($offering->course?->name_ar ?? '—'); ?></td>
                        <td><?php echo e($offering->course?->code ?: '—'); ?></td>
                        <td><?php echo e($offering->academic_year); ?></td>
                        <td><?php echo e($semesterLabels[$offering->semester] ?? $offering->semester); ?></td>
                        <td><?php echo e($offering->level); ?></td>
                        <td><?php echo e($offering->instructor_name ?: '—'); ?></td>
                        <td><?php echo e($offering->assistant_name ?: '—'); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="10">
                            <div class="empty-state">لا توجد طروحات دراسية حتى الآن</div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/monanashaat/Projects/university-survey/resources/views/admin/academic/offerings/index.blade.php ENDPATH**/ ?>