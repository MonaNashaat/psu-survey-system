<?php
    $pageTitle = 'إدارة الكليات';
    $pageSubtitle = 'إضافة وعرض الكليات داخل النظام';
?>

<?php $__env->startSection('content'); ?>
    <div class="page-actions">
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-secondary">لوحة المؤشرات</a>
        <a href="<?php echo e(route('admin.academic.departments.index')); ?>" class="btn btn-secondary">الأقسام</a>
        <a href="<?php echo e(route('admin.academic.courses.index')); ?>" class="btn btn-secondary">المقررات</a>
        <a href="<?php echo e(route('admin.academic.offerings.index')); ?>" class="btn btn-secondary">المواد المسجلة</a>
    </div>

    <div class="grid-2">
        <div class="card">
            <div class="card-body">
                <h2 class="section-title">إضافة كلية جديدة</h2>

                <form method="POST" action="<?php echo e(route('admin.academic.faculties.store')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label class="form-label">اسم الكلية بالعربية</label>
                        <input type="text" name="name_ar" value="<?php echo e(old('name_ar')); ?>" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">اسم الكلية بالإنجليزية</label>
                        <input type="text" name="name_en" value="<?php echo e(old('name_en')); ?>">
                    </div>

                    <button type="submit" class="btn btn-primary">إضافة الكلية</button>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <h2 class="section-title">ملخص سريع</h2>

                <div class="grid-2">
                    <div class="card stats-card">
                        <div class="stats-title">عدد الكليات</div>
                        <div class="stats-value"><?php echo e($faculties->count()); ?></div>
                    </div>

                    <div class="card stats-card">
                        <div class="stats-title">آخر إضافة</div>
                        <div class="stats-value" style="font-size:18px;">
                            <?php echo e($faculties->first()?->name_ar ?? '—'); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div style="height: 16px;"></div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>الاسم بالعربية</th>
                    <th>الاسم بالإنجليزية</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $faculties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faculty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($faculty->id); ?></td>
                        <td><?php echo e($faculty->name_ar); ?></td>
                        <td><?php echo e($faculty->name_en ?: '—'); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="3">
                            <div class="empty-state">لا توجد كليات حتى الآن</div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/monanashaat/Projects/university-survey/resources/views/admin/academic/faculties/index.blade.php ENDPATH**/ ?>