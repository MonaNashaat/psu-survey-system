<?php
    $pageTitle = 'لوحة المؤشرات';
    $pageSubtitle = 'نظرة عامة على أداء منظومة الاستبيانات';
?>

<?php $__env->startSection('content'); ?>
    <div class="grid-4">
        <div class="card stats-card">
            <div class="stats-title">إجمالي الاستبيانات</div>
            <div class="stats-value"><?php echo e($totalSurveys); ?></div>
        </div>

        <div class="card stats-card">
            <div class="stats-title">الاستبيانات النشطة</div>
            <div class="stats-value"><?php echo e($activeSurveys); ?></div>
        </div>

        <div class="card stats-card">
            <div class="stats-title">إجمالي الردود</div>
            <div class="stats-value"><?php echo e($totalResponses); ?></div>
        </div>

        <div class="card stats-card">
            <div class="stats-title">أحدث الاستبيانات</div>
            <div class="stats-value"><?php echo e($latestSurveys->count()); ?></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/monanashaat/Projects/university-survey/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>