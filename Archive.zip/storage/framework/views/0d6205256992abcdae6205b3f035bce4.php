<?php
    $pageTitle = $survey->title;
    $pageSubtitle = 'عرض تفاصيل الاستبيان والمحاور والأسئلة';
?>

<?php $__env->startSection('content'); ?>
    <?php
        $semesterLabels = [
            'first' => 'الفصل الدراسي الأول',
            'second' => 'الفصل الدراسي الثاني',
            'summer' => 'الفصل الصيفي',
        ];

        $isCourseSurvey = !empty($survey->course_offering_id);
        $semesterName = $semesterLabels[$survey->courseOffering?->semester] ?? '-';
        $standaloneQuestions = $survey->questions->whereNull('survey_section_id');
    ?>

    <div class="page-actions">
        <a href="<?php echo e(route('admin.surveys.index')); ?>" class="btn btn-secondary">رجوع</a>
        <a href="<?php echo e(route('admin.surveys.edit', $survey->id)); ?>" class="btn btn-secondary">تعديل</a>
        <a href="<?php echo e(route('surveys.show', $survey->id)); ?>" target="_blank" class="btn btn-secondary">فتح الرابط العام</a>
        <a href="<?php echo e(route('admin.surveys.permissions', $survey->id)); ?>" class="btn btn-secondary">الصلاحيات</a>
        <a href="<?php echo e(route('admin.surveys.results', $survey->id)); ?>" class="btn btn-primary">عرض النتائج</a>

        <form method="POST" action="<?php echo e(route('admin.surveys.destroy', $survey->id)); ?>"
              onsubmit="return confirm('هل أنت متأكدة من حذف هذا الاستبيان؟')"
              style="display:inline;">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button class="btn btn-danger" type="submit">حذف</button>
        </form>
    </div>

    <div class="grid-2">
        <div class="card">
            <div class="card-body">
                <h2 class="section-title">بيانات الاستبيان</h2>

                <div class="grid-2">
                    <div>
                        <p><strong>العنوان:</strong> <?php echo e($survey->title); ?></p>
                        <p><strong>الوصف:</strong> <?php echo e($survey->description ?: '—'); ?></p>
                        <p><strong>النوع:</strong> <?php echo e($isCourseSurvey ? 'استبيان مرتبط بمادة' : 'استبيان عام'); ?></p>
                        <p>
                            <strong>الحالة:</strong>
                            <?php if($survey->is_active): ?>
                                <span class="badge badge-success">نشط</span>
                            <?php else: ?>
                                <span class="badge badge-warning">غير نشط</span>
                            <?php endif; ?>
                        </p>
                        <p>
                            <strong>تعدد الردود:</strong>
                            <?php echo e($survey->allow_multiple_submissions ? 'مسموح' : 'غير مسموح'); ?>

                        </p>
                    </div>

                    <div>
                        <p><strong>عدد المحاور:</strong> <?php echo e($survey->sections->count()); ?></p>
                        <p><strong>عدد الأسئلة المستقلة:</strong> <?php echo e($standaloneQuestions->count()); ?></p>
                        <p><strong>إجمالي الأسئلة:</strong> <?php echo e($survey->questions->count()); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <h2 class="section-title">الربط الأكاديمي</h2>

                <?php if($isCourseSurvey): ?>
                    <p><strong>الكلية:</strong> <?php echo e($survey->courseOffering?->course?->department?->faculty?->name_ar ?? '-'); ?></p>
                    <p><strong>القسم:</strong> <?php echo e($survey->courseOffering?->course?->department?->name_ar ?? ($survey->department_name ?? '-')); ?></p>
                    <p><strong>المقرر:</strong> <?php echo e($survey->courseOffering?->course?->name_ar ?? ($survey->course_title ?? '-')); ?></p>
                    <p><strong>كود المقرر:</strong> <?php echo e($survey->courseOffering?->course?->code ?? '-'); ?></p>
                    <p><strong>الفصل الدراسي:</strong> <?php echo e($semesterName); ?></p>
                    <p><strong>الفرقة:</strong> <?php echo e($survey->courseOffering?->level ?? ($survey->level ?? '-')); ?></p>
                    <p><strong>العام الدراسي:</strong> <?php echo e($survey->courseOffering?->academic_year ?? ($survey->academic_year ?? '-')); ?></p>
                    <p><strong>القائم على التدريس:</strong> <?php echo e($survey->courseOffering?->instructor_name ?? '-'); ?></p>
                    <p><strong>الهيئة المعاونة:</strong> <?php echo e($survey->courseOffering?->assistant_name ?? '-'); ?></p>
                <?php else: ?>
                    <div class="empty-state" style="padding: 10px 0;">
                        هذا استبيان عام وغير مرتبط بمادة مسجلة.
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div style="height: 16px;"></div>

    <?php $__empty_1 = true; $__currentLoopData = $survey->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card" style="margin-bottom:16px;">
            <div class="card-body">
                <h2 class="section-title"><?php echo e($section->title); ?></h2>

                <?php $__currentLoopData = $section->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="question-card" style="border:1px solid #e4e8f0; border-radius:14px; padding:14px; margin-bottom:12px; background:#fafbff;">
                        <div style="font-weight:700; margin-bottom:8px;">
                            <?php echo e($question->display_order); ?>. <?php echo e($question->question_text); ?>

                        </div>

                        <div style="color:#6b7280; font-size:14px; margin-bottom:8px;">
                            النوع:
                            <?php if($question->type === 'scale'): ?>
                                تقييم 1-5
                            <?php elseif($question->type === 'mcq'): ?>
                                اختيار من متعدد
                            <?php else: ?>
                                نص مفتوح
                            <?php endif; ?>

                            | <?php echo e($question->is_required ? 'إجباري' : 'اختياري'); ?>

                        </div>

                        <?php if($question->options->count()): ?>
                            <ul style="margin:0; padding-right:18px;">
                                <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($option->option_text); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="card">
            <div class="card-body">
                <div class="empty-state">لا توجد محاور مضافة لهذا الاستبيان.</div>
            </div>
        </div>
    <?php endif; ?>

    <?php if($standaloneQuestions->count()): ?>
        <div class="card">
            <div class="card-body">
                <h2 class="section-title">أسئلة مستقلة</h2>

                <?php $__currentLoopData = $standaloneQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="question-card" style="border:1px solid #e4e8f0; border-radius:14px; padding:14px; margin-bottom:12px; background:#fafbff;">
                        <div style="font-weight:700; margin-bottom:8px;">
                            <?php echo e($question->question_text); ?>

                        </div>

                        <div style="color:#6b7280; font-size:14px;">
                            النوع:
                            <?php if($question->type === 'scale'): ?>
                                تقييم 1-5
                            <?php elseif($question->type === 'mcq'): ?>
                                اختيار من متعدد
                            <?php else: ?>
                                نص مفتوح
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/monanashaat/Projects/university-survey/resources/views/admin/surveys/show.blade.php ENDPATH**/ ?>