<?php
    $pageTitle = 'تسجيل الدخول | منصة الاستبيانات الأكاديمية';
?>

<?php $__env->startSection('content'); ?>
    <div class="auth-card-header">
        <h2>تسجيل الدخول</h2>
        <p>أدخل بياناتك للوصول إلى لوحة التحكم.</p>
    </div>

    <?php if(session('status')): ?>
        <div class="status-box">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="error-box">
            <ul style="margin:0; padding-right:18px;">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="email">البريد الإلكتروني</label>
            <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus autocomplete="username">
        </div>

        <div class="form-group">
            <label for="password">كلمة المرور</label>
            <input id="password" type="password" name="password" required autocomplete="current-password">
        </div>

        <div class="remember-row">
            <label class="remember-box" for="remember_me">
                <input id="remember_me" type="checkbox" name="remember">
                <span>تذكرني</span>
            </label>

            <?php if(Route::has('password.request')): ?>
                <a class="forgot-link" href="<?php echo e(route('password.request')); ?>">
                    نسيت كلمة المرور؟
                </a>
            <?php endif; ?>
        </div>

        <button type="submit" class="auth-btn">
            دخول إلى النظام
        </button>
    </form>

    <div class="auth-footer-note">
        جميع الحقوق محفوظة © جامعة بورسعيد
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/monanashaat/Projects/university-survey/resources/views/auth/login.blade.php ENDPATH**/ ?>