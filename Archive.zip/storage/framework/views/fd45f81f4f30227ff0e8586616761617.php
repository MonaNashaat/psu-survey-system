<?php
    $pageTitle = 'إدارة الاستبيانات';
    $pageSubtitle = 'عرض وإدارة الاستبيانات الجامعية';
?>

<?php $__env->startSection('content'); ?>
    <?php
        $currentUser = auth()->user();
    ?>

    <?php if($currentUser->isUniversityAdmin() || $currentUser->isFacultyAdmin() || $currentUser->isDepartmentAdmin()): ?>
        <div class="page-actions">
            <a href="<?php echo e(route('admin.surveys.create')); ?>" class="btn btn-primary">إنشاء استبيان جديد</a>
        </div>
    <?php endif; ?>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>العنوان</th>
                    <th>مستوى الاستبيان</th>
                    <th>نوع الربط</th>
                    <th>الكلية</th>
                    <th>القسم</th>
                    <th>المقرر</th>
                    <th>العام الدراسي</th>
                    <th>الحالة</th>
                    <th>الحد الأقصى للردود</th>
                    <th>الإجراءات</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $surveys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $survey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $isCourseSurvey = !empty($survey->course_offering_id);

                        $surveyFaculty = $survey->courseOffering?->course?->department?->faculty?->name_ar
                            ?? $survey->faculty?->name_ar
                            ?? '—';

                        $surveyDepartment = $survey->courseOffering?->course?->department?->name_ar
                            ?? $survey->department?->name_ar
                            ?? $survey->department_name
                            ?? '—';

                        $surveyCourse = $survey->courseOffering?->course?->name_ar
                            ?? $survey->course_title
                            ?? '—';

                        $surveyAcademicYear = $survey->courseOffering?->academic_year
                            ?? $survey->academic_year
                            ?? '—';

                        $responsesCount = $survey->responses_count ?? $survey->responses()->count();

                        $canEdit = false;

                        if ($currentUser->isUniversityAdmin()) {
                            $canEdit = true;
                        } elseif ($currentUser->isFacultyAdmin()) {
                            $canEdit = (
                                ($survey->scope_level === 'faculty' && $survey->faculty_id === $currentUser->faculty_id) ||
                                ($survey->scope_level === 'department' && $survey->faculty_id === $currentUser->faculty_id)
                            );
                        } elseif ($currentUser->isDepartmentAdmin()) {
                            $canEdit = (
                                $survey->scope_level === 'department' &&
                                $survey->department_id === $currentUser->department_id
                            );
                        }
                    ?>

                    <tr>
                        <td><?php echo e($survey->title); ?></td>

                        <td>
                            <?php if($survey->scope_level === 'university'): ?>
                                <span class="badge badge-success">جامعة</span>
                            <?php elseif($survey->scope_level === 'faculty'): ?>
                                <span class="badge badge-warning">كلية</span>
                            <?php else: ?>
                                <span class="badge badge-secondary">قسم</span>
                            <?php endif; ?>
                        </td>

                        <td>
                            <?php if($isCourseSurvey): ?>
                                <span class="badge badge-success">مقرر</span>
                            <?php else: ?>
                                <span class="badge badge-warning">عام</span>
                            <?php endif; ?>
                        </td>

                        <td><?php echo e($surveyFaculty); ?></td>
                        <td><?php echo e($surveyDepartment); ?></td>
                        <td><?php echo e($surveyCourse); ?></td>
                        <td><?php echo e($surveyAcademicYear); ?></td>

                        <td>
                            <?php if($survey->is_active): ?>
                                <span class="badge badge-success">نشط</span>
                            <?php else: ?>
                                <span class="badge badge-warning">غير نشط</span>
                            <?php endif; ?>

                            <?php if($survey->expected_responses && $responsesCount >= $survey->expected_responses): ?>
                                <br><small style="color:#b45309;">تم بلوغ الحد</small>
                            <?php endif; ?>
                        </td>

                        <td>
                            <?php if($survey->expected_responses): ?>
                                <?php echo e($responsesCount); ?> / <?php echo e($survey->expected_responses); ?>

                                <?php if($survey->auto_close_on_limit): ?>
                                    <br><small style="color:#6b7280;">إغلاق تلقائي</small>
                                <?php endif; ?>
                            <?php else: ?>
                                —
                            <?php endif; ?>
                        </td>

                        <td>
                            <div class="page-actions" style="margin:0;">
                                <?php if($currentUser->isUniversityAdmin() || $currentUser->isFacultyAdmin() || $currentUser->isDepartmentAdmin()): ?>
                                    <a href="<?php echo e(route('admin.surveys.show', $survey->id)); ?>" class="btn btn-secondary">تفاصيل</a>

                                    <?php if($canEdit): ?>
                                        <a href="<?php echo e(route('admin.surveys.edit', $survey->id)); ?>" class="btn btn-secondary">تعديل</a>
                                    <?php endif; ?>

                                    <a href="<?php echo e(route('admin.surveys.results', $survey->id)); ?>" class="btn btn-primary">النتائج</a>

                                    <?php if($currentUser->isUniversityAdmin()): ?>
                                        <a href="<?php echo e(route('admin.surveys.permissions', $survey->id)); ?>" class="btn btn-secondary">الصلاحيات</a>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <a href="<?php echo e(route('admin.surveys.results', $survey->id)); ?>" class="btn btn-primary">عرض النتائج</a>
                                    <a href="<?php echo e(route('admin.surveys.export.excel', $survey->id)); ?>" class="btn btn-success">Excel</a>
                                    <a href="<?php echo e(route('admin.surveys.export.pdf', $survey->id)); ?>" class="btn btn-secondary">PDF</a>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="10">
                            <div class="empty-state">لا توجد استبيانات حتى الآن</div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/monanashaat/Projects/university-survey/resources/views/admin/surveys/index.blade.php ENDPATH**/ ?>