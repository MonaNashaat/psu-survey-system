<?php
    $pageTitle = 'قوالب الاستبيانات';
    $pageSubtitle = 'عرض وإدارة القوالب الجاهزة';
?>

<?php $__env->startSection('content'); ?>
    <div class="page-actions">
        <a href="<?php echo e(route('admin.templates.create')); ?>" class="btn btn-primary">إنشاء قالب جديد</a>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>اسم القالب</th>
                    <th>التصنيف</th>
                    <th>القسم</th>
                    <th>الوصف</th>
                    <th>عدد المحاور</th>
                    <th>عدد الأسئلة</th>
                    <th>الحالة</th>
                    <th>الإجراءات</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($template->name); ?></td>
                        <td>
                            <?php if($template->template_type === 'institutional'): ?>
                                <span class="badge badge-success">مؤسسي</span>
                            <?php else: ?>
                                <span class="badge badge-warning">خاص بالقسم</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($template->department?->name_ar ?? '—'); ?></td>
                        <td><?php echo e($template->description ?: '—'); ?></td>
                        <td><?php echo e($template->sections_count); ?></td>
                        <td><?php echo e($template->questions_count); ?></td>
                        <td>
                            <?php if($template->is_active): ?>
                                <span class="badge badge-success">نشط</span>
                            <?php else: ?>
                                <span class="badge badge-warning">غير نشط</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="page-actions" style="margin:0;">
                                <a href="<?php echo e(route('admin.templates.edit', $template->id)); ?>" class="btn btn-secondary">تعديل</a>

                                <form method="POST"
                                      action="<?php echo e(route('admin.templates.destroy', $template->id)); ?>"
                                      onsubmit="return confirm('هل أنت متأكد من حذف القالب؟')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger">حذف</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8">
                            <div class="empty-state">لا توجد قوالب حتى الآن</div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/monanashaat/Projects/university-survey/resources/views/admin/templates/index.blade.php ENDPATH**/ ?>