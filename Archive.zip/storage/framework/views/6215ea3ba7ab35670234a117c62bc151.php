<?php
    $pageTitle = 'إنشاء استبيان جديد';
    $pageSubtitle = 'إضافة استبيان جديد مع إمكانية استخدام قالب جاهز';
?>

<?php $__env->startSection('content'); ?>
    <?php
        $departmentsJson = $departments->map(function ($department) {
            return [
                'id' => $department->id,
                'name_ar' => $department->name_ar,
                'faculty_id' => $department->faculty_id,
            ];
        })->values();

        $coursesJson = $courses->map(function ($course) {
            return [
                'id' => $course->id,
                'name_ar' => $course->name_ar,
                'code' => $course->code,
                'department_id' => $course->department_id,
            ];
        })->values();

        $offeringsJson = $courseOfferings->map(function ($offering) {
            return [
                'id' => $offering->id,
                'course_id' => $offering->course_id,
                'academic_year' => $offering->academic_year,
                'semester' => $offering->semester,
                'level' => $offering->level,
                'instructor_name' => $offering->instructor_name,
                'assistant_name' => $offering->assistant_name,
            ];
        })->values();

        $templatesJson = $templates->map(function ($template) {
            return [
                'id' => $template->id,
                'name' => $template->name,
                'template_type' => $template->template_type,
                'department_id' => $template->department_id,
            ];
        })->values();
    ?>

    <div class="page-actions">
        <a href="<?php echo e(route('admin.surveys.index')); ?>" class="btn btn-secondary">رجوع إلى الاستبيانات</a>
        <a href="<?php echo e(route('admin.templates.index')); ?>" class="btn btn-secondary">قوالب الاستبيانات</a>
    </div>

    <div class="card">
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('admin.surveys.store')); ?>">
                <?php echo csrf_field(); ?>

                <div class="grid-2">
                    <div class="form-group">
                        <label class="form-label">عنوان الاستبيان</label>
                        <input type="text" name="title" value="<?php echo e(old('title')); ?>">
                    </div>

                    <div class="form-group">
                        <label class="form-label">نوع الاستبيان</label>
                        <select name="survey_scope" id="survey_scope">
                            <option value="general" <?php echo e(old('survey_scope', 'general') == 'general' ? 'selected' : ''); ?>>استبيان عام</option>
                            <option value="course" <?php echo e(old('survey_scope') == 'course' ? 'selected' : ''); ?>>استبيان مرتبط بمادة</option>
                        </select>
                    </div>
                </div>

                <div class="grid-2">
                    <?php if(auth()->user()->isAdmin()): ?>
                        <div class="form-group">
                            <label class="form-label">تصنيف الاستبيان</label>
                            <select name="survey_type" id="survey_type">
                                <option value="institutional" <?php echo e(old('survey_type', 'institutional') == 'institutional' ? 'selected' : ''); ?>>
                                    استبيان مؤسسي
                                </option>
                                <option value="department" <?php echo e(old('survey_type') == 'department' ? 'selected' : ''); ?>>
                                    استبيان خاص بالقسم
                                </option>
                            </select>
                        </div>

                        <div class="form-group" id="survey-department-wrapper">
                            <label class="form-label">القسم</label>
                            <select name="department_id" id="survey_department_id">
                                <option value="">اختر القسم</option>
                                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($department->id); ?>" <?php echo e(old('department_id') == $department->id ? 'selected' : ''); ?>>
                                        <?php echo e($department->name_ar); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    <?php else: ?>
                        <input type="hidden" name="survey_type" id="survey_type" value="department">
                        <input type="hidden" name="department_id" id="survey_department_id" value="<?php echo e(auth()->user()->department_id); ?>">
                    <?php endif; ?>
                </div>

                <div class="grid-2">
                    <div class="form-group">
                        <label class="form-label">استخدام قالب جاهز</label>
                        <select name="template_id" id="template_id">
                            <option value="">إنشاء استبيان بدون قالب</option>
                        </select>
                        <small style="display:block; margin-top:8px; color:#6b7280;">
                            سيتم عرض القوالب المناسبة حسب تصنيف الاستبيان والقسم.
                        </small>
                    </div>
                </div>

                <div id="course-offering-wrapper">
                    <div class="grid-2">
                        <div class="form-group">
                            <label class="form-label">الكلية</label>
                            <select id="faculty_id">
                                <option value="">اختر الكلية</option>
                                <?php $__currentLoopData = $faculties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faculty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($faculty->id); ?>"><?php echo e($faculty->name_ar); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label">القسم الأكاديمي للمقرر</label>
                            <select id="department_id">
                                <option value="">اختر القسم</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label">المقرر</label>
                            <select id="course_id">
                                <option value="">اختر المقرر</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label">المادة المسجلة</label>
                            <select name="course_offering_id" id="course_offering_id">
                                <option value="">اختر المادة المسجلة</option>
                            </select>
                        </div>
                    </div>

                    <div id="offering-preview" class="card" style="display:none; margin-bottom:16px; background:#f8f9ff; border-color:#d9def7;">
                        <div class="card-body" id="offering-preview-content"></div>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">وصف الاستبيان</label>
                    <textarea name="description"><?php echo e(old('description')); ?></textarea>
                </div>

                <div class="checkbox-row">
                    <input type="checkbox" id="is_active" name="is_active" checked>
                    <label for="is_active" style="margin:0;">تفعيل الاستبيان</label>
                </div>

                <div class="checkbox-row">
                    <input type="checkbox" id="allow_multiple_submissions" name="allow_multiple_submissions">
                    <label for="allow_multiple_submissions" style="margin:0;">السماح بأكثر من رد من نفس الجهاز</label>
                </div>

                <div id="manual-builder-wrapper">
                    <hr style="margin:24px 0; border:none; border-top:1px solid #e4e8f0;">

                    <div class="page-actions" style="justify-content:space-between; align-items:center;">
                        <h2 class="section-title" style="margin:0;">المحاور والأسئلة</h2>
                        <button type="button" class="btn btn-primary" onclick="addSection()">إضافة محور</button>
                    </div>

                    <div id="sections-wrapper"></div>

                    <hr style="margin:24px 0; border:none; border-top:1px solid #e4e8f0;">

                    <div class="form-group">
                        <label class="form-label">سؤال التعليقات الإضافية</label>
                        <input type="text" name="comments_question" value="<?php echo e(old('comments_question', 'تعليقات أخرى')); ?>">
                    </div>
                </div>

                <div class="page-actions">
                    <button type="submit" class="btn btn-primary">حفظ الاستبيان</button>
                    <a href="<?php echo e(route('admin.surveys.index')); ?>" class="btn btn-secondary">إلغاء</a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .section-box,
    .question-box {
        border: 1px solid #e4e8f0;
        border-radius: 16px;
        padding: 16px;
        margin-bottom: 16px;
        background: #fafbff;
    }

    .section-title-inline {
        margin-bottom: 12px;
        font-size: 18px;
        font-weight: 800;
        color: #28335f;
    }

    .option-input {
        margin-bottom: 8px;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    let sectionIndex = 0;

    function addSection() {
        const wrapper = document.getElementById('sections-wrapper');

        const html = `
            <div class="section-box" id="section-${sectionIndex}">
                <div class="section-title-inline">محور جديد</div>

                <div class="form-group">
                    <label class="form-label">عنوان المحور</label>
                    <input type="text" name="sections[${sectionIndex}][title]">
                </div>

                <div id="questions-wrapper-${sectionIndex}"></div>

                <div class="page-actions">
                    <button type="button" class="btn btn-primary" onclick="addQuestion(${sectionIndex})">إضافة سؤال</button>
                    <button type="button" class="btn btn-danger" onclick="removeElement('section-${sectionIndex}')">حذف المحور</button>
                </div>
            </div>
        `;

        wrapper.insertAdjacentHTML('beforeend', html);
        sectionIndex++;
    }

    function addQuestion(sectionIdx) {
        const wrapper = document.getElementById(`questions-wrapper-${sectionIdx}`);
        const questionCount = wrapper.querySelectorAll('.question-box').length;

        const html = `
            <div class="question-box" id="section-${sectionIdx}-question-${questionCount}">
                <div class="form-group">
                    <label class="form-label">نص السؤال</label>
                    <textarea name="sections[${sectionIdx}][questions][${questionCount}][question_text]"></textarea>
                </div>

                <div class="form-group">
                    <label class="form-label">نوع السؤال</label>
                    <select name="sections[${sectionIdx}][questions][${questionCount}][type]" onchange="toggleOptions(this, ${sectionIdx}, ${questionCount})">
                        <option value="scale">تقييم 1-5</option>
                        <option value="mcq">اختيار من متعدد</option>
                        <option value="text">نص مفتوح</option>
                    </select>
                </div>

                <div class="checkbox-row">
                    <input type="checkbox" id="required-${sectionIdx}-${questionCount}" name="sections[${sectionIdx}][questions][${questionCount}][is_required]" checked>
                    <label for="required-${sectionIdx}-${questionCount}" style="margin:0;">سؤال إجباري</label>
                </div>

                <div class="form-group options-box" id="options-box-${sectionIdx}-${questionCount}">
                    <label class="form-label">الخيارات</label>
                    <div class="option-input">
                        <input type="text" name="sections[${sectionIdx}][questions][${questionCount}][options][]" value="غير موافق بشدة">
                    </div>
                    <div class="option-input">
                        <input type="text" name="sections[${sectionIdx}][questions][${questionCount}][options][]" value="غير موافق">
                    </div>
                    <div class="option-input">
                        <input type="text" name="sections[${sectionIdx}][questions][${questionCount}][options][]" value="محايد">
                    </div>
                    <div class="option-input">
                        <input type="text" name="sections[${sectionIdx}][questions][${questionCount}][options][]" value="أوافق">
                    </div>
                    <div class="option-input">
                        <input type="text" name="sections[${sectionIdx}][questions][${questionCount}][options][]" value="أوافق بشدة">
                    </div>
                </div>

                <div class="page-actions">
                    <button type="button" class="btn btn-danger" onclick="removeElement('section-${sectionIdx}-question-${questionCount}')">حذف السؤال</button>
                </div>
            </div>
        `;

        wrapper.insertAdjacentHTML('beforeend', html);
    }

    function toggleOptions(selectEl, sectionIdx, questionIdx) {
        const box = document.getElementById(`options-box-${sectionIdx}-${questionIdx}`);
        box.style.display = selectEl.value === 'text' ? 'none' : 'block';
    }

    function removeElement(id) {
        const el = document.getElementById(id);
        if (el) el.remove();
    }
</script>

<script>
    const departmentsData = <?php echo json_encode($departmentsJson, 15, 512) ?>;
    const coursesData = <?php echo json_encode($coursesJson, 15, 512) ?>;
    const offeringsData = <?php echo json_encode($offeringsJson, 15, 512) ?>;
    const templatesData = <?php echo json_encode($templatesJson, 15, 512) ?>;

    const oldTemplateId = <?php echo json_encode(old('template_id'), 15, 512) ?>;
    const oldSurveyType = <?php echo json_encode(old('survey_type', auth()->user()->isDepartmentManager() ? 'department' : 'institutional'), 512) ?>;

    const semesterLabels = {
        first: 'الفصل الدراسي الأول',
        second: 'الفصل الدراسي الثاني',
        summer: 'الفصل الصيفي',
    };

    const facultySelect = document.getElementById('faculty_id');
    const departmentSelect = document.getElementById('department_id');
    const courseSelect = document.getElementById('course_id');
    const offeringSelect = document.getElementById('course_offering_id');
    const offeringPreview = document.getElementById('offering-preview');
    const offeringPreviewContent = document.getElementById('offering-preview-content');

    const surveyScopeSelect = document.getElementById('survey_scope');
    const courseOfferingWrapper = document.getElementById('course-offering-wrapper');

    const surveyTypeSelect = document.getElementById('survey_type');
    const surveyDepartmentSelect = document.getElementById('survey_department_id');
    const surveyDepartmentWrapper = document.getElementById('survey-department-wrapper');

    const templateSelect = document.getElementById('template_id');
    const manualBuilderWrapper = document.getElementById('manual-builder-wrapper');

    function resetSelect(select, placeholder) {
        select.innerHTML = `<option value="">${placeholder}</option>`;
    }

    function populateDepartments() {
        resetSelect(departmentSelect, 'اختر القسم');
        resetSelect(courseSelect, 'اختر المقرر');
        resetSelect(offeringSelect, 'اختر المادة المسجلة');
        offeringPreview.style.display = 'none';
        offeringPreviewContent.innerHTML = '';

        const facultyId = facultySelect.value;
        if (!facultyId) return;

        const filteredDepartments = departmentsData.filter(
            department => String(department.faculty_id) === String(facultyId)
        );

        filteredDepartments.forEach(department => {
            const option = document.createElement('option');
            option.value = department.id;
            option.textContent = department.name_ar;
            departmentSelect.appendChild(option);
        });
    }

    function populateCourses() {
        resetSelect(courseSelect, 'اختر المقرر');
        resetSelect(offeringSelect, 'اختر المادة المسجلة');
        offeringPreview.style.display = 'none';
        offeringPreviewContent.innerHTML = '';

        const departmentId = departmentSelect.value;
        if (!departmentId) return;

        const filteredCourses = coursesData.filter(
            course => String(course.department_id) === String(departmentId)
        );

        filteredCourses.forEach(course => {
            const option = document.createElement('option');
            option.value = course.id;
            option.textContent = `${course.name_ar}${course.code ? ' - ' + course.code : ''}`;
            courseSelect.appendChild(option);
        });
    }

    function populateOfferings() {
        resetSelect(offeringSelect, 'اختر المادة المسجلة');
        offeringPreview.style.display = 'none';
        offeringPreviewContent.innerHTML = '';

        const courseId = courseSelect.value;
        if (!courseId) return;

        const filteredOfferings = offeringsData.filter(
            offering => String(offering.course_id) === String(courseId)
        );

        filteredOfferings.forEach(offering => {
            const option = document.createElement('option');
            option.value = offering.id;
            option.textContent = `${offering.academic_year} - ${semesterLabels[offering.semester] ?? offering.semester} - ${offering.level}`;
            offeringSelect.appendChild(option);
        });
    }

    function showOfferingPreview() {
        offeringPreview.style.display = 'none';
        offeringPreviewContent.innerHTML = '';

        const selectedOfferingId = offeringSelect.value;
        if (!selectedOfferingId) return;

        const selectedOffering = offeringsData.find(
            offering => String(offering.id) === String(selectedOfferingId)
        );

        if (!selectedOffering) return;

        offeringPreviewContent.innerHTML = `
            <strong>بيانات المادة المسجلة:</strong><br>
            العام الدراسي: ${selectedOffering.academic_year}<br>
            الفصل الدراسي: ${semesterLabels[selectedOffering.semester] ?? selectedOffering.semester}<br>
            الفرقة: ${selectedOffering.level}<br>
            القائم على التدريس: ${selectedOffering.instructor_name ?? '-'}<br>
            الهيئة المعاونة: ${selectedOffering.assistant_name ?? '-'}
        `;
        offeringPreview.style.display = 'block';
    }

    function toggleSurveyScope() {
        if (surveyScopeSelect.value === 'course') {
            courseOfferingWrapper.style.display = 'block';
        } else {
            courseOfferingWrapper.style.display = 'none';

            facultySelect.value = '';
            resetSelect(departmentSelect, 'اختر القسم');
            resetSelect(courseSelect, 'اختر المقرر');
            resetSelect(offeringSelect, 'اختر المادة المسجلة');
            offeringPreview.style.display = 'none';
            offeringPreviewContent.innerHTML = '';
        }
    }

    function toggleSurveyTypeDepartmentField() {
        if (!surveyTypeSelect || !surveyDepartmentWrapper) return;

        if (surveyTypeSelect.value === 'department') {
            surveyDepartmentWrapper.style.display = 'block';
        } else {
            surveyDepartmentWrapper.style.display = 'none';

            if (surveyDepartmentSelect) {
                surveyDepartmentSelect.value = '';
            }
        }
    }

    function populateTemplates() {
        if (!templateSelect || !surveyTypeSelect) return;

        const selectedSurveyType = surveyTypeSelect.value;
        const selectedDepartmentId = surveyDepartmentSelect ? surveyDepartmentSelect.value : null;
        const currentValue = templateSelect.value || oldTemplateId || '';

        templateSelect.innerHTML = '<option value="">إنشاء استبيان بدون قالب</option>';

        const filteredTemplates = templatesData.filter(template => {
            if (template.template_type !== selectedSurveyType) {
                return false;
            }

            if (selectedSurveyType === 'department') {
                if (selectedDepartmentId) {
                    return String(template.department_id) === String(selectedDepartmentId);
                }
                return false;
            }

            return true;
        });

        filteredTemplates.forEach(template => {
            const option = document.createElement('option');
            option.value = template.id;
            option.textContent = template.name;

            if (String(currentValue) === String(template.id)) {
                option.selected = true;
            }

            templateSelect.appendChild(option);
        });

        toggleTemplateMode();
    }

    function toggleTemplateMode() {
        if (!templateSelect || !manualBuilderWrapper) return;

        if (templateSelect.value) {
            manualBuilderWrapper.style.display = 'none';
        } else {
            manualBuilderWrapper.style.display = 'block';

            if (!document.getElementById('sections-wrapper').children.length) {
                addSection();
            }
        }
    }

    facultySelect.addEventListener('change', populateDepartments);
    departmentSelect.addEventListener('change', populateCourses);
    courseSelect.addEventListener('change', populateOfferings);
    offeringSelect.addEventListener('change', showOfferingPreview);

    surveyScopeSelect.addEventListener('change', toggleSurveyScope);

    if (surveyTypeSelect) {
        surveyTypeSelect.addEventListener('change', function () {
            toggleSurveyTypeDepartmentField();
            populateTemplates();
        });
    }

    if (surveyDepartmentSelect) {
        surveyDepartmentSelect.addEventListener('change', populateTemplates);
    }

    if (templateSelect) {
        templateSelect.addEventListener('change', toggleTemplateMode);
    }

    if (surveyTypeSelect && oldSurveyType) {
        surveyTypeSelect.value = oldSurveyType;
    }

    toggleSurveyScope();
    toggleSurveyTypeDepartmentField();
    populateTemplates();

    if (!templateSelect.value && !document.getElementById('sections-wrapper').children.length) {
        addSection();
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/monanashaat/Projects/university-survey/resources/views/admin/surveys/create.blade.php ENDPATH**/ ?>