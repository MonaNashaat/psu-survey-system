<?php
    $pageTitle = 'تم الإرسال';
?>

<?php $__env->startSection('content'); ?>

<div class="guest-card" style="padding:40px; text-align:center;">

    <div class="alert alert-success">
        تم إرسال الاستبيان بنجاح
    </div>

    <h2 style="margin-top:18px; color:#28335f; font-weight:800;">
        شكرًا لمشاركتك
    </h2>

    <p style="color:#6b7280; line-height:1.9; margin-top:10px;">
        تم استلام ردك بنجاح، وسيتم التعامل مع جميع البيانات بسرية تامة.
    </p>

    
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guest-survey', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/monanashaat/Projects/university-survey/resources/views/surveys/thankyou.blade.php ENDPATH**/ ?>