<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>نتائج الاستبيان</title>
    <style>
        body {
            font-family: DejaVu Sans, sans-serif;
            direction: rtl;
            text-align: right;
            font-size: 12px;
        }
        h1, h2, h3 {
            margin-bottom: 8px;
        }
        .meta {
            margin-bottom: 20px;
            line-height: 1.8;
        }
        .section {
            margin-top: 18px;
        }
        .section-title {
            background: #ddd;
            padding: 8px;
            font-weight: bold;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 8px;
        }
        th, td {
            border: 1px solid #999;
            padding: 6px;
            vertical-align: top;
        }
        .comment {
            margin: 6px 0;
            padding: 6px;
            border: 1px solid #ccc;
            background: #fafafa;
        }
    </style>
</head>
<body>
    <?php
        $semesterLabels = [
            'first' => 'الفصل الدراسي الأول',
            'second' => 'الفصل الدراسي الثاني',
            'summer' => 'الفصل الصيفي',
        ];

        $semesterName = $semesterLabels[$survey->courseOffering?->semester] ?? '-';
    ?>
    <h1>نتائج الاستبيان</h1>

    <div class="meta">
        <div><strong>العنوان:</strong> <?php echo e($survey->title); ?></div>
        <div><strong>الكلية:</strong> <?php echo e($survey->courseOffering?->course?->department?->faculty?->name_ar ?? '-'); ?></div>
        <div><strong>القسم:</strong> <?php echo e($survey->courseOffering?->course?->department?->name_ar ?? ($survey->department_name ?? '-')); ?></div>
        <div><strong>المقرر:</strong> <?php echo e($survey->courseOffering?->course?->name_ar ?? ($survey->course_title ?? '-')); ?></div>
        <div><strong>كود المقرر:</strong> <?php echo e($survey->courseOffering?->course?->code ?? '-'); ?></div>
        <div><strong>الفصل الدراسي:</strong> <?php echo e($semesterName); ?></div>
        <div><strong>الفرقة:</strong> <?php echo e($survey->courseOffering?->level ?? ($survey->level ?? '-')); ?></div>
        <div><strong>العام الدراسي:</strong> <?php echo e($survey->courseOffering?->academic_year ?? ($survey->academic_year ?? '-')); ?></div>
        <div><strong>القائم على التدريس:</strong> <?php echo e($survey->courseOffering?->instructor_name ?? '-'); ?></div>
        <div><strong>الهيئة المعاونة:</strong> <?php echo e($survey->courseOffering?->assistant_name ?? '-'); ?></div>
        <div><strong>عدد الردود:</strong> <?php echo e($responsesCount); ?></div>
    </div>

    <?php $__currentLoopData = $survey->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="section">
            <div class="section-title"><?php echo e($section->title); ?></div>

            <?php $__currentLoopData = $section->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $stats = $questionStats[$question->id] ?? null;
                ?>

                <h3><?php echo e($question->display_order); ?>. <?php echo e($question->question_text); ?></h3>

                <?php if($stats && in_array($stats['type'], ['scale', 'mcq'])): ?>
                    <p><strong>عدد الإجابات:</strong> <?php echo e($stats['total_answers']); ?></p>
                    <?php if(!is_null($stats['average'])): ?>
                        <p><strong>المتوسط:</strong> <?php echo e(number_format($stats['average'], 2)); ?></p>
                    <?php endif; ?>

                    <table>
                        <thead>
                            <tr>
                                <th>الاختيار</th>
                                <th>عدد المرات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $stats['distribution']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item['label']); ?></td>
                                    <td><?php echo e($item['count']); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php elseif($stats && $stats['type'] === 'text'): ?>
                    <p><strong>عدد التعليقات:</strong> <?php echo e($stats['total_answers']); ?></p>

                    <?php $__empty_1 = true; $__currentLoopData = $stats['comments']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="comment"><?php echo e($comment); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="comment">لا توجد تعليقات.</div>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php
        $standaloneQuestions = $survey->questions->whereNull('survey_section_id');
    ?>

    <?php if($standaloneQuestions->count()): ?>
        <div class="section">
            <div class="section-title">أسئلة إضافية</div>

            <?php $__currentLoopData = $standaloneQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $stats = $questionStats[$question->id] ?? null;
                ?>

                <h3><?php echo e($question->question_text); ?></h3>

                <?php if($stats && $stats['type'] === 'text'): ?>
                    <p><strong>عدد التعليقات:</strong> <?php echo e($stats['total_answers']); ?></p>

                    <?php $__empty_1 = true; $__currentLoopData = $stats['comments']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="comment"><?php echo e($comment); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="comment">لا توجد تعليقات.</div>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</body>
</html><?php /**PATH /Users/monanashaat/Projects/university-survey/resources/views/admin/surveys/results-pdf.blade.php ENDPATH**/ ?>