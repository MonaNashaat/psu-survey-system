<?php
    $pageTitle = 'نتائج الاستبيان';
    $pageSubtitle = 'عرض وتحليل نتائج الاستبيان';
?>

<?php $__env->startSection('content'); ?>
    <?php
        $semesterLabels = [
            'first' => 'الفصل الدراسي الأول',
            'second' => 'الفصل الدراسي الثاني',
            'summer' => 'الفصل الصيفي',
        ];

        $isCourseSurvey = !empty($survey->course_offering_id);
        $semesterName = $semesterLabels[$survey->courseOffering?->semester] ?? '-';
        $standaloneQuestions = $survey->questions->whereNull('survey_section_id');
    ?>

    <div class="page-actions">
        <a href="<?php echo e(route('admin.surveys.index')); ?>" class="btn btn-secondary">رجوع</a>
        <a href="<?php echo e(route('admin.surveys.show', $survey->id)); ?>" class="btn btn-secondary">تفاصيل الاستبيان</a>
        <a href="<?php echo e(route('surveys.show', $survey->id)); ?>" target="_blank" class="btn btn-secondary">فتح الرابط العام</a>
        <a href="<?php echo e(route('admin.surveys.export.excel', $survey->id)); ?>" class="btn btn-success">تصدير Excel</a>
        
    </div>

    <div class="grid-2">
        <div class="card">
            <div class="card-body">
                <h2 class="section-title">بيانات الاستبيان</h2>

                <div class="grid-2">
                    <div>
                        <p><strong>العنوان:</strong> <?php echo e($survey->title); ?></p>
                        <p><strong>الوصف:</strong> <?php echo e($survey->description ?: '—'); ?></p>
                        <p><strong>عدد الردود:</strong> <span class="badge badge-success"><?php echo e($responsesCount); ?></span></p>
                        <p><strong>النوع:</strong> <?php echo e($isCourseSurvey ? 'استبيان مرتبط بمادة' : 'استبيان عام'); ?></p>
                    </div>

                    <div>
                        <?php if($isCourseSurvey): ?>
                            <p><strong>الكلية:</strong> <?php echo e($survey->courseOffering?->course?->department?->faculty?->name_ar ?? '-'); ?></p>
                            <p><strong>القسم:</strong> <?php echo e($survey->courseOffering?->course?->department?->name_ar ?? ($survey->department_name ?? '-')); ?></p>
                            <p><strong>المقرر:</strong> <?php echo e($survey->courseOffering?->course?->name_ar ?? ($survey->course_title ?? '-')); ?></p>
                            <p><strong>كود المقرر:</strong> <?php echo e($survey->courseOffering?->course?->code ?? '-'); ?></p>
                            <p><strong>الفصل الدراسي:</strong> <?php echo e($semesterName); ?></p>
                            <p><strong>الفرقة:</strong> <?php echo e($survey->courseOffering?->level ?? ($survey->level ?? '-')); ?></p>
                            <p><strong>العام الدراسي:</strong> <?php echo e($survey->courseOffering?->academic_year ?? ($survey->academic_year ?? '-')); ?></p>
                            <p><strong>القائم على التدريس:</strong> <?php echo e($survey->courseOffering?->instructor_name ?? '-'); ?></p>
                            <p><strong>الهيئة المعاونة:</strong> <?php echo e($survey->courseOffering?->assistant_name ?? '-'); ?></p>
                        <?php else: ?>
                            <div class="empty-state" style="padding: 10px 0;">
                                هذا استبيان عام وغير مرتبط بمادة مسجلة.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div style="height: 16px;"></div>

    <?php $__currentLoopData = $survey->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card" style="margin-bottom:16px;">
            <div class="card-body">
                <h2 class="section-title"><?php echo e($section->title); ?></h2>

                <?php $__currentLoopData = $section->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $stats = $questionStats[$question->id] ?? null;
                    ?>

                    <div style="border:1px solid #e4e8f0; border-radius:14px; padding:16px; margin-bottom:14px; background:#fafbff;">
                        <div style="font-weight:700; margin-bottom:10px;">
                            <?php echo e($question->display_order); ?>. <?php echo e($question->question_text); ?>

                        </div>

                        <?php if($stats && in_array($stats['type'], ['scale', 'mcq'])): ?>
                            <div style="margin-bottom:10px; color:#6b7280;">
                                <div><strong>عدد الإجابات:</strong> <?php echo e($stats['total_answers']); ?></div>
                                <?php if(!is_null($stats['average'])): ?>
                                    <div><strong>المتوسط:</strong> <?php echo e(number_format($stats['average'], 2)); ?></div>
                                <?php endif; ?>
                            </div>

                            <div class="table-wrap" style="box-shadow:none;">
                                <table style="min-width:auto;">
                                    <thead>
                                        <tr>
                                            <th>الاختيار</th>
                                            <th>عدد المرات</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $stats['distribution']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($item['label']); ?></td>
                                                <td><?php echo e($item['count']); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php elseif($stats && $stats['type'] === 'text'): ?>
                            <div style="margin-bottom:10px; color:#6b7280;">
                                <strong>عدد التعليقات:</strong> <?php echo e($stats['total_answers']); ?>

                            </div>

                            <?php $__empty_1 = true; $__currentLoopData = $stats['comments']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div style="background:#fff; border:1px solid #e4e8f0; border-radius:12px; padding:12px; margin-bottom:8px;">
                                    <?php echo e($comment); ?>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="empty-state" style="padding:12px;">لا توجد تعليقات حتى الآن.</div>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php if($standaloneQuestions->count()): ?>
        <div class="card">
            <div class="card-body">
                <h2 class="section-title">أسئلة إضافية</h2>

                <?php $__currentLoopData = $standaloneQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $stats = $questionStats[$question->id] ?? null;
                    ?>

                    <div style="border:1px solid #e4e8f0; border-radius:14px; padding:16px; margin-bottom:14px; background:#fafbff;">
                        <div style="font-weight:700; margin-bottom:10px;">
                            <?php echo e($question->question_text); ?>

                        </div>

                        <?php if($stats && $stats['type'] === 'text'): ?>
                            <div style="margin-bottom:10px; color:#6b7280;">
                                <strong>عدد التعليقات:</strong> <?php echo e($stats['total_answers']); ?>

                            </div>

                            <?php $__empty_1 = true; $__currentLoopData = $stats['comments']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div style="background:#fff; border:1px solid #e4e8f0; border-radius:12px; padding:12px; margin-bottom:8px;">
                                    <?php echo e($comment); ?>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="empty-state" style="padding:12px;">لا توجد تعليقات حتى الآن.</div>
                            <?php endif; ?>
                        <?php elseif($stats && in_array($stats['type'], ['scale', 'mcq'])): ?>
                            <div style="margin-bottom:10px; color:#6b7280;">
                                <div><strong>عدد الإجابات:</strong> <?php echo e($stats['total_answers']); ?></div>
                                <?php if(!is_null($stats['average'])): ?>
                                    <div><strong>المتوسط:</strong> <?php echo e(number_format($stats['average'], 2)); ?></div>
                                <?php endif; ?>
                            </div>

                            <div class="table-wrap" style="box-shadow:none;">
                                <table style="min-width:auto;">
                                    <thead>
                                        <tr>
                                            <th>الاختيار</th>
                                            <th>عدد المرات</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $stats['distribution']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($item['label']); ?></td>
                                                <td><?php echo e($item['count']); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php
    $pageTitle = 'نتائج الاستبيان';
    $pageSubtitle = 'تحليل الردود والإجابات الخاصة بالاستبيان';
?>

<?php $__env->startSection('content'); ?>
    <?php
        $semesterLabels = [
            'first' => 'الفصل الدراسي الأول',
            'second' => 'الفصل الدراسي الثاني',
            'summer' => 'الفصل الصيفي',
        ];

        $scopeLabel = match($survey->scope_level) {
            'university' => 'جامعة',
            'faculty' => 'كلية',
            'department' => 'قسم',
            default => '—',
        };

        $semesterName = $semesterLabels[$survey->courseOffering?->semester] ?? ($survey->semester ?? '—');

        $surveyFaculty = $survey->courseOffering?->course?->department?->faculty?->name_ar
            ?? $survey->faculty?->name_ar
            ?? '—';

        $surveyDepartment = $survey->courseOffering?->course?->department?->name_ar
            ?? $survey->department?->name_ar
            ?? $survey->department_name
            ?? '—';

        $surveyCourse = $survey->courseOffering?->course?->name_ar
            ?? $survey->course_title
            ?? '—';

        $surveyAcademicYear = $survey->courseOffering?->academic_year
            ?? $survey->academic_year
            ?? '—';

        $isCourseSurvey = !empty($survey->course_offering_id);
        $responsesProgress = $survey->expected_responses ? ($responsesCount . ' / ' . $survey->expected_responses) : 'غير محدد';
    ?>

    <div class="page-actions">
        <a href="<?php echo e(route('admin.surveys.index')); ?>" class="btn btn-secondary">رجوع</a>
        <a href="<?php echo e(route('admin.surveys.show', $survey->id)); ?>" class="btn btn-secondary">تفاصيل الاستبيان</a>
        <a href="<?php echo e(route('surveys.show', $survey->id)); ?>" class="btn btn-secondary" target="_blank">فتح الرابط العام</a>
        <a href="<?php echo e(route('admin.surveys.export.excel', $survey->id)); ?>" class="btn btn-success">تصدير Excel</a>
        <a href="<?php echo e(route('admin.surveys.export.pdf', $survey->id)); ?>" class="btn btn-secondary">تصدير PDF</a>
    </div>

    <div class="grid-2">
        <div class="card stats-card">
            <div class="stats-title">عدد الردود</div>
            <div class="stats-value"><?php echo e($responsesCount); ?></div>
            <div class="stats-note"><?php echo e($responsesProgress); ?></div>
        </div>

        <div class="card stats-card">
            <div class="stats-title">مستوى الاستبيان</div>
            <div class="stats-value"><?php echo e($scopeLabel); ?></div>
            <div class="stats-note"><?php echo e($isCourseSurvey ? 'استبيان مرتبط بمقرر' : 'استبيان عام'); ?></div>
        </div>
    </div>

    <div style="height: 16px;"></div>

    <div class="card">
        <div class="card-body">
            <h2 class="section-title">بيانات الاستبيان</h2>

            <div class="meta-grid">
                <div><strong>العنوان:</strong> <?php echo e($survey->title); ?></div>
                <div><strong>الوصف:</strong> <?php echo e($survey->description ?: '—'); ?></div>
                <div><strong>المستوى:</strong> <?php echo e($scopeLabel); ?></div>
                <div><strong>نوع الربط:</strong> <?php echo e($isCourseSurvey ? 'مقرر' : 'عام'); ?></div>
                <div><strong>الكلية:</strong> <?php echo e($surveyFaculty); ?></div>
                <div><strong>القسم:</strong> <?php echo e($surveyDepartment); ?></div>
                <div><strong>المقرر:</strong> <?php echo e($surveyCourse); ?></div>
                <div><strong>العام الدراسي:</strong> <?php echo e($surveyAcademicYear); ?></div>
                <div><strong>الفصل الدراسي:</strong> <?php echo e($semesterName); ?></div>
                <div><strong>الفرقة:</strong> <?php echo e($survey->courseOffering?->level ?? $survey->level ?? '—'); ?></div>
                <div><strong>القائم على التدريس:</strong> <?php echo e($survey->courseOffering?->instructor_name ?? '—'); ?></div>
                <div><strong>الهيئة المعاونة:</strong> <?php echo e($survey->courseOffering?->assistant_name ?? '—'); ?></div>
                <div><strong>الحالة:</strong> <?php echo e($survey->is_active ? 'نشط' : 'غير نشط'); ?></div>
                <div><strong>الحد الأقصى للردود:</strong> <?php echo e($survey->expected_responses ?? 'غير محدد'); ?></div>
                <div><strong>إغلاق تلقائي عند بلوغ الحد:</strong> <?php echo e($survey->auto_close_on_limit ? 'نعم' : 'لا'); ?></div>
                <div><strong>السماح بأكثر من رد من نفس الجهاز:</strong> <?php echo e($survey->allow_multiple_submissions ? 'نعم' : 'لا'); ?></div>
            </div>
        </div>
    </div>

    <?php $__currentLoopData = $survey->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card section-card">
            <div class="card-body">
                <h2 class="section-title"><?php echo e($section->title); ?></h2>

                <?php $__currentLoopData = $section->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $stats = $questionStats[$question->id] ?? null;
                    ?>

                    <div class="question-box">
                        <div class="question-title">
                            <?php echo e($question->display_order); ?>. <?php echo e($question->question_text); ?>

                        </div>

                        <?php if($stats && in_array($stats['type'], ['scale', 'mcq'])): ?>
                            <div class="question-meta">
                                <span><strong>عدد الإجابات:</strong> <?php echo e($stats['total_answers']); ?></span>
                                <?php if(!is_null($stats['average'])): ?>
                                    <span><strong>المتوسط:</strong> <?php echo e(number_format($stats['average'], 2)); ?></span>
                                <?php endif; ?>
                            </div>

                            <div class="table-wrap">
                                <table>
                                    <thead>
                                        <tr>
                                            <th>الاختيار</th>
                                            <th>عدد المرات</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $stats['distribution']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($item['label']); ?></td>
                                                <td><?php echo e($item['count']); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php elseif($stats && $stats['type'] === 'text'): ?>
                            <div class="question-meta">
                                <span><strong>عدد التعليقات:</strong> <?php echo e($stats['total_answers']); ?></span>
                            </div>

                            <?php $__empty_1 = true; $__currentLoopData = $stats['comments']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="comment-box"><?php echo e($comment); ?></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="empty-state small-empty-state">لا توجد تعليقات حتى الآن</div>
                            <?php endif; ?>
                        <?php else: ?>
                            <div class="empty-state small-empty-state">لا توجد بيانات متاحة لهذا السؤال</div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php
        $standaloneQuestions = $survey->questions->whereNull('survey_section_id');
    ?>

    <?php if($standaloneQuestions->count()): ?>
        <div class="card section-card">
            <div class="card-body">
                <h2 class="section-title">أسئلة إضافية</h2>

                <?php $__currentLoopData = $standaloneQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $stats = $questionStats[$question->id] ?? null;
                    ?>

                    <div class="question-box">
                        <div class="question-title"><?php echo e($question->question_text); ?></div>

                        <?php if($stats && $stats['type'] === 'text'): ?>
                            <div class="question-meta">
                                <span><strong>عدد التعليقات:</strong> <?php echo e($stats['total_answers']); ?></span>
                            </div>

                            <?php $__empty_1 = true; $__currentLoopData = $stats['comments']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="comment-box"><?php echo e($comment); ?></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="empty-state small-empty-state">لا توجد تعليقات حتى الآن</div>
                            <?php endif; ?>
                        <?php elseif($stats && in_array($stats['type'], ['scale', 'mcq'])): ?>
                            <div class="question-meta">
                                <span><strong>عدد الإجابات:</strong> <?php echo e($stats['total_answers']); ?></span>
                                <?php if(!is_null($stats['average'])): ?>
                                    <span><strong>المتوسط:</strong> <?php echo e(number_format($stats['average'], 2)); ?></span>
                                <?php endif; ?>
                            </div>

                            <div class="table-wrap">
                                <table>
                                    <thead>
                                        <tr>
                                            <th>الاختيار</th>
                                            <th>عدد المرات</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $stats['distribution']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($item['label']); ?></td>
                                                <td><?php echo e($item['count']); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="empty-state small-empty-state">لا توجد بيانات متاحة لهذا السؤال</div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .meta-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 12px 24px;
        line-height: 1.9;
    }

    .section-card {
        margin-top: 16px;
    }

    .question-box {
        border: 1px solid #e4e8f0;
        border-radius: 16px;
        padding: 16px;
        margin-top: 16px;
        background: #fafbff;
    }

    .question-title {
        font-size: 16px;
        font-weight: 800;
        color: #28335f;
        margin-bottom: 12px;
        line-height: 1.8;
    }

    .question-meta {
        display: flex;
        gap: 24px;
        flex-wrap: wrap;
        margin-bottom: 12px;
        color: #4b5563;
    }

    .comment-box {
        background: #fff;
        border: 1px solid #e4e8f0;
        border-radius: 12px;
        padding: 12px 14px;
        margin-top: 10px;
        line-height: 1.9;
    }

    .small-empty-state {
        padding: 16px;
        margin-top: 8px;
    }

    @media (max-width: 768px) {
        .meta-grid {
            grid-template-columns: 1fr;
        }
    }
</style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/monanashaat/Projects/university-survey/resources/views/admin/surveys/results.blade.php ENDPATH**/ ?>