<?php
    $pageTitle = 'إنشاء قالب جديد';
    $pageSubtitle = 'بناء قالب استبيان يمكن استخدامه لاحقًا';
?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('admin.templates.store')); ?>">
                <?php echo csrf_field(); ?>

                <div class="grid-2">
                    <div class="form-group">
                        <label class="form-label">اسم القالب</label>
                        <input type="text" name="name" value="<?php echo e(old('name')); ?>">
                    </div>

                    <div class="checkbox-row" style="margin-top: 32px;">
                        <input type="checkbox" id="is_active" name="is_active" checked>
                        <label for="is_active" style="margin:0;">تفعيل القالب</label>
                    </div>
                </div>

                <div class="grid-2">
                    <?php if(auth()->user()->isAdmin()): ?>
                        <div class="form-group">
                            <label class="form-label">تصنيف القالب</label>
                            <select name="template_type" id="template_type">
                                <option value="institutional" <?php echo e(old('template_type', 'institutional') == 'institutional' ? 'selected' : ''); ?>>قالب مؤسسي</option>
                                <option value="department" <?php echo e(old('template_type') == 'department' ? 'selected' : ''); ?>>قالب خاص بالقسم</option>
                            </select>
                        </div>

                        <div class="form-group" id="department-wrapper">
                            <label class="form-label">القسم</label>
                            <select name="department_id">
                                <option value="">اختر القسم</option>
                                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($department->id); ?>" <?php echo e(old('department_id') == $department->id ? 'selected' : ''); ?>>
                                        <?php echo e($department->name_ar); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    <?php else: ?>
                        <input type="hidden" name="template_type" value="department">
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label class="form-label">وصف القالب</label>
                    <textarea name="description"><?php echo e(old('description')); ?></textarea>
                </div>

                <hr style="margin:24px 0; border:none; border-top:1px solid #e4e8f0;">

                <div class="page-actions" style="justify-content:space-between; align-items:center;">
                    <h2 class="section-title" style="margin:0;">المحاور والأسئلة</h2>
                    <button type="button" class="btn btn-primary" onclick="addSection()">إضافة محور</button>
                </div>

                <div id="sections-wrapper"></div>

                <hr style="margin:24px 0; border:none; border-top:1px solid #e4e8f0;">

                <div class="form-group">
                    <label class="form-label">سؤال التعليقات الإضافية</label>
                    <input type="text" name="comments_question" value="<?php echo e(old('comments_question', 'تعليقات أخرى')); ?>">
                </div>

                <div class="page-actions">
                    <button type="submit" class="btn btn-primary">حفظ القالب</button>
                    <a href="<?php echo e(route('admin.templates.index')); ?>" class="btn btn-secondary">إلغاء</a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .section-box, .question-box {
        border: 1px solid #e4e8f0;
        border-radius: 16px;
        padding: 16px;
        margin-bottom: 16px;
        background: #fafbff;
    }

    .section-title-inline {
        margin-bottom: 12px;
        font-size: 18px;
        font-weight: 800;
        color: #28335f;
    }

    .option-input {
        margin-bottom: 8px;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    let sectionIndex = 0;

    function addSection() {
        const wrapper = document.getElementById('sections-wrapper');

        const html = `
            <div class="section-box" id="section-${sectionIndex}">
                <div class="section-title-inline">محور جديد</div>

                <div class="form-group">
                    <label class="form-label">عنوان المحور</label>
                    <input type="text" name="sections[${sectionIndex}][title]">
                </div>

                <div id="questions-wrapper-${sectionIndex}"></div>

                <div class="page-actions">
                    <button type="button" class="btn btn-primary" onclick="addQuestion(${sectionIndex})">إضافة سؤال</button>
                    <button type="button" class="btn btn-danger" onclick="removeElement('section-${sectionIndex}')">حذف المحور</button>
                </div>
            </div>
        `;

        wrapper.insertAdjacentHTML('beforeend', html);
        sectionIndex++;
    }

    function addQuestion(sectionIdx) {
        const wrapper = document.getElementById(`questions-wrapper-${sectionIdx}`);
        const questionCount = wrapper.querySelectorAll('.question-box').length;

        const html = `
            <div class="question-box" id="section-${sectionIdx}-question-${questionCount}">
                <div class="form-group">
                    <label class="form-label">نص السؤال</label>
                    <textarea name="sections[${sectionIdx}][questions][${questionCount}][question_text]"></textarea>
                </div>

                <div class="form-group">
                    <label class="form-label">نوع السؤال</label>
                    <select name="sections[${sectionIdx}][questions][${questionCount}][type]" onchange="toggleOptions(this, ${sectionIdx}, ${questionCount})">
                        <option value="scale">تقييم 1-5</option>
                        <option value="mcq">اختيار من متعدد</option>
                        <option value="text">نص مفتوح</option>
                    </select>
                </div>

                <div class="checkbox-row">
                    <input type="checkbox" id="required-${sectionIdx}-${questionCount}" name="sections[${sectionIdx}][questions][${questionCount}][is_required]" checked>
                    <label for="required-${sectionIdx}-${questionCount}" style="margin:0;">سؤال إجباري</label>
                </div>

                <div class="form-group options-box" id="options-box-${sectionIdx}-${questionCount}">
                    <label class="form-label">الخيارات</label>
                    <div class="option-input"><input type="text" name="sections[${sectionIdx}][questions][${questionCount}][options][]" value="غير موافق بشدة"></div>
                    <div class="option-input"><input type="text" name="sections[${sectionIdx}][questions][${questionCount}][options][]" value="غير موافق"></div>
                    <div class="option-input"><input type="text" name="sections[${sectionIdx}][questions][${questionCount}][options][]" value="محايد"></div>
                    <div class="option-input"><input type="text" name="sections[${sectionIdx}][questions][${questionCount}][options][]" value="أوافق"></div>
                    <div class="option-input"><input type="text" name="sections[${sectionIdx}][questions][${questionCount}][options][]" value="أوافق بشدة"></div>
                </div>

                <div class="page-actions">
                    <button type="button" class="btn btn-danger" onclick="removeElement('section-${sectionIdx}-question-${questionCount}')">حذف السؤال</button>
                </div>
            </div>
        `;

        wrapper.insertAdjacentHTML('beforeend', html);
    }

    function toggleOptions(selectEl, sectionIdx, questionIdx) {
        const box = document.getElementById(`options-box-${sectionIdx}-${questionIdx}`);
        box.style.display = selectEl.value === 'text' ? 'none' : 'block';
    }

    function removeElement(id) {
        const el = document.getElementById(id);
        if (el) el.remove();
    }

    addSection();

    const templateTypeSelect = document.getElementById('template_type');
    const departmentWrapper = document.getElementById('department-wrapper');

    function toggleDepartmentField() {
        if (!templateTypeSelect || !departmentWrapper) return;
        departmentWrapper.style.display = templateTypeSelect.value === 'department' ? 'block' : 'none';
    }

    if (templateTypeSelect) {
        templateTypeSelect.addEventListener('change', toggleDepartmentField);
        toggleDepartmentField();
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/monanashaat/Projects/university-survey/resources/views/admin/templates/create.blade.php ENDPATH**/ ?>