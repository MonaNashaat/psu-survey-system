<?php
    $pageTitle = 'صلاحيات الاستبيان';
    $pageSubtitle = 'إدارة المستخدمين المسموح لهم بعرض نتائج هذا الاستبيان';
?>

<?php $__env->startSection('content'); ?>
    <div class="page-actions">
        <a href="<?php echo e(route('admin.surveys.show', $survey->id)); ?>" class="btn btn-secondary">الرجوع إلى الاستبيان</a>
        <a href="<?php echo e(route('admin.surveys.index')); ?>" class="btn btn-secondary">الاستبيانات</a>
    </div>

    <div class="grid-2">
        <div class="card">
            <div class="card-body">
                <h2 class="section-title">منح صلاحية جديدة</h2>

                <p style="margin-bottom:16px;">
                    <strong>الاستبيان:</strong> <?php echo e($survey->title); ?>

                </p>

                <form method="POST" action="<?php echo e(route('admin.surveys.permissions.store', $survey->id)); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label class="form-label">المستخدم</label>
                        <select name="user_id" required>
                            <option value="">اختر المستخدم</option>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>">
                                    <?php echo e($user->name); ?> - <?php echo e($user->email); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">نوع الصلاحية</label>
                        <select name="permission_type" required>
                            <option value="view_results">عرض النتائج</option>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary">منح الصلاحية</button>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <h2 class="section-title">ملخص سريع</h2>

                <div class="grid-2">
                    <div class="card stats-card">
                        <div class="stats-title">عدد الصلاحيات الحالية</div>
                        <div class="stats-value"><?php echo e($survey->permissions->count()); ?></div>
                    </div>

                    <div class="card stats-card">
                        <div class="stats-title">نوع الصلاحية المتاحة</div>
                        <div class="stats-value" style="font-size:18px;">عرض النتائج</div>
                    </div>
                </div>

                <div style="height: 12px;"></div>

                <div class="card stats-card">
                    <div class="stats-title">اسم الاستبيان</div>
                    <div class="stats-value" style="font-size:18px;">
                        <?php echo e($survey->title); ?>

                    </div>
                    <div class="stats-note">
                        إدارة الوصول إلى نتائج هذا الاستبيان
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div style="height: 16px;"></div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>المستخدم</th>
                    <th>البريد الإلكتروني</th>
                    <th>نوع الصلاحية</th>
                    <th>إجراء</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $survey->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($permission->user->name); ?></td>
                        <td><?php echo e($permission->user->email); ?></td>
                        <td>
                            <?php if($permission->permission_type === 'view_results'): ?>
                                <span class="badge badge-success">عرض النتائج</span>
                            <?php else: ?>
                                <span class="badge badge-warning"><?php echo e($permission->permission_type); ?></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <form method="POST"
                                  action="<?php echo e(route('admin.surveys.permissions.destroy', [$survey->id, $permission->id])); ?>"
                                  onsubmit="return confirm('هل تريد حذف هذه الصلاحية؟')"
                                  style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger" type="submit">حذف</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4">
                            <div class="empty-state">لا توجد صلاحيات مضافة حتى الآن</div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/monanashaat/Projects/university-survey/resources/views/admin/surveys/permissions.blade.php ENDPATH**/ ?>