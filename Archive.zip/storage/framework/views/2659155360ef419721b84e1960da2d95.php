<?php
    $pageTitle = $survey->title;
?>

<?php $__env->startSection('content'); ?>
<?php
    $semesterLabels = [
        'first' => 'الفصل الدراسي الأول',
        'second' => 'الفصل الدراسي الثاني',
        'summer' => 'الفصل الصيفي',
    ];

    $isCourseSurvey = !empty($survey->course_offering_id);
    $semesterName = $semesterLabels[$survey->courseOffering?->semester] ?? '-';
    $standaloneQuestions = $survey->questions->whereNull('survey_section_id');
?>

<?php $__env->startPush('styles'); ?>
<style>
    .survey-header {
        padding: 28px;
        margin-bottom: 18px;
    }

    .survey-badge {
        display: inline-flex;
        align-items: center;
        padding: 8px 14px;
        border-radius: 999px;
        background: #eef1ff;
        color: #28335f;
        font-size: 13px;
        font-weight: 700;
        margin-bottom: 14px;
    }

    .survey-title {
        margin: 0 0 10px;
        font-size: 30px;
        font-weight: 800;
        color: #28335f;
        line-height: 1.4;
    }

    .survey-description {
        margin: 0;
        color: #6b7280;
        line-height: 1.9;
    }

    .meta-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 12px 18px;
        margin-top: 22px;
        padding-top: 20px;
        border-top: 1px solid #e4e8f0;
    }

    .meta-item {
        background: #fafbff;
        border: 1px solid #e4e8f0;
        border-radius: 14px;
        padding: 12px 14px;
        font-size: 14px;
        line-height: 1.8;
    }

    .meta-item strong {
        color: #28335f;
    }

    .section-box {
        margin-bottom: 18px;
        overflow: hidden;
    }

    .section-title {
        background: linear-gradient(135deg, #28335f 0%, #3a4a84 100%);
        color: #fff;
        padding: 16px 20px;
        font-weight: 800;
        font-size: 18px;
    }

    .question {
        padding: 18px 20px;
        border-top: 1px solid #eef1f5;
    }

    .question:first-child {
        border-top: 0;
    }

    .question-text {
        margin-bottom: 14px;
        font-weight: 700;
        color: #222;
        line-height: 1.9;
    }

    .required-star {
        color: #d32f2f;
        margin-right: 4px;
    }

    .options {
        display: flex;
        flex-wrap: wrap;
        gap: 12px;
    }

    .option-label {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        background: #f8f9fd;
        border: 1px solid #e4e8f0;
        padding: 10px 14px;
        border-radius: 14px;
        cursor: pointer;
        transition: 0.2s ease;
        font-size: 14px;
    }

    .option-label:hover {
        border-color: #bfc8ea;
        background: #f3f5ff;
    }

    textarea {
        width: 100%;
        min-height: 120px;
        border: 1px solid #d5dbe7;
        border-radius: 14px;
        padding: 14px;
        resize: vertical;
        font-family: 'Alexandria', sans-serif;
        font-size: 14px;
        color: #1f2a44;
    }

    .standalone-box {
        padding: 22px;
        margin-top: 18px;
    }

    .standalone-title {
        margin: 0 0 14px;
        font-size: 20px;
        color: #28335f;
    }

    .error {
        color: #c62828;
        margin-top: 8px;
        font-size: 13px;
        line-height: 1.7;
    }

    .submit-area {
        text-align: center;
        margin-top: 24px;
    }

    .submit-btn {
        background: linear-gradient(135deg, #28335f 0%, #3f5297 100%);
        color: white;
        border: 0;
        padding: 14px 34px;
        border-radius: 14px;
        cursor: pointer;
        font-size: 15px;
        font-weight: 800;
        font-family: 'Alexandria', sans-serif;
    }

    @media (max-width: 800px) {
        .meta-grid {
            grid-template-columns: 1fr;
        }

        .survey-title {
            font-size: 24px;
        }

        .options {
            flex-direction: column;
        }

        .survey-header,
        .standalone-box,
        .question,
        .section-title {
            padding-left: 16px;
            padding-right: 16px;
        }
    }
</style>
<?php $__env->stopPush(); ?>

<div class="guest-card survey-header">
    <div class="survey-badge">
        <?php echo e($isCourseSurvey ? 'استبيان مرتبط بمادة' : 'استبيان عام'); ?>

    </div>

    <h1 class="survey-title"><?php echo e($survey->title); ?></h1>

    <?php if($survey->description): ?>
        <p class="survey-description"><?php echo e($survey->description); ?></p>
    <?php endif; ?>

    <div class="meta-grid">
        <?php if($isCourseSurvey): ?>
            <div class="meta-item"><strong>الكلية:</strong> <?php echo e($survey->courseOffering?->course?->department?->faculty?->name_ar ?? '-'); ?></div>
            <div class="meta-item"><strong>القسم:</strong> <?php echo e($survey->courseOffering?->course?->department?->name_ar ?? '-'); ?></div>
            <div class="meta-item"><strong>اسم المقرر:</strong> <?php echo e($survey->courseOffering?->course?->name_ar ?? ($survey->course_title ?? '-')); ?></div>
            <div class="meta-item"><strong>كود المقرر:</strong> <?php echo e($survey->courseOffering?->course?->code ?? '-'); ?></div>
            <div class="meta-item"><strong>العام الدراسي:</strong> <?php echo e($survey->courseOffering?->academic_year ?? ($survey->academic_year ?? '-')); ?></div>
            <div class="meta-item"><strong>الفصل الدراسي:</strong> <?php echo e($semesterName); ?></div>
            <div class="meta-item"><strong>الفرقة:</strong> <?php echo e($survey->courseOffering?->level ?? ($survey->level ?? '-')); ?></div>
            <div class="meta-item"><strong>القائم على التدريس:</strong> <?php echo e($survey->courseOffering?->instructor_name ?? '-'); ?></div>
            <div class="meta-item"><strong>الهيئة المعاونة:</strong> <?php echo e($survey->courseOffering?->assistant_name ?? '-'); ?></div>
        <?php else: ?>
            <div class="meta-item"><strong>نوع الاستبيان:</strong> عام</div>
        <?php endif; ?>
    </div>
</div>

<?php if(session('duplicate_error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('duplicate_error')); ?>

    </div>
<?php endif; ?>

<?php if(!empty($alreadySubmittedByCookie) && !$survey->allow_multiple_submissions): ?>
    <div class="alert alert-warning">
        يبدو أنه تم إرسال هذا الاستبيان من هذا الجهاز من قبل.
    </div>
<?php endif; ?>

<div class="guest-card" style="padding: 0 0 24px 0;">
    <form method="POST" action="<?php echo e(route('surveys.submit', $survey->id)); ?>">
        <?php echo csrf_field(); ?>

        <?php $__currentLoopData = $survey->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="section-box">
                <div class="section-title"><?php echo e($section->title); ?></div>

                <?php $__currentLoopData = $section->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="question">
                        <div class="question-text">
                            <?php echo e($question->display_order); ?>. <?php echo e($question->question_text); ?>

                            <?php if($question->is_required): ?>
                                <span class="required-star">*</span>
                            <?php endif; ?>
                        </div>

                        <?php if($question->type === 'mcq' || $question->type === 'scale'): ?>
                            <div class="options">
                                <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label class="option-label">
                                        <input
                                            type="radio"
                                            name="answers[<?php echo e($question->id); ?>]"
                                            value="<?php echo e($option->id); ?>"
                                            <?php echo e(old('answers.' . $question->id) == $option->id ? 'checked' : ''); ?>

                                        >
                                        <span><?php echo e($option->option_text); ?></span>
                                    </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php elseif($question->type === 'text'): ?>
                            <textarea name="answers[<?php echo e($question->id); ?>]"><?php echo e(old('answers.' . $question->id)); ?></textarea>
                        <?php endif; ?>

                        <?php $__errorArgs = ['answers.' . $question->id];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="error"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if($standaloneQuestions->count()): ?>
            <div class="standalone-box">
                <h3 class="standalone-title">تعليقات إضافية</h3>

                <?php $__currentLoopData = $standaloneQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="question" style="padding: 0 0 18px 0; border-top:0;">
                        <div class="question-text">
                            <?php echo e($question->question_text); ?>

                        </div>

                        <textarea name="answers[<?php echo e($question->id); ?>]"><?php echo e(old('answers.' . $question->id)); ?></textarea>

                        <?php $__errorArgs = ['answers.' . $question->id];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="error"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <div class="submit-area">
            <button class="submit-btn" type="submit">إرسال الاستبيان</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guest-survey', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/monanashaat/Projects/university-survey/resources/views/surveys/show.blade.php ENDPATH**/ ?>