<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($pageTitle ?? 'لوحة التحكم'); ?></title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Alexandria:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
    <div class="admin-overlay" id="adminOverlay"></div>

    <div class="admin-app">
        <aside class="admin-sidebar" id="adminSidebar">
            <div class="sidebar-brand">
                <div class="sidebar-brand-logos">
                    <div class="sidebar-logo-box">
                        <img src="<?php echo e(asset('images/university-logo.png')); ?>" alt="University Logo">
                    </div>

                    <div class="sidebar-logo-box">
                        <img src="<?php echo e(asset('images/system-logo.png')); ?>" alt="System Logo">
                    </div>
                </div>

                <div class="sidebar-brand-text">
                    <h2>منصة الاستبيانات الأكاديمية</h2>
                    <p>لوحة الإدارة والتحكم</p>
                </div>
            </div>

            <div class="sidebar-section">
                <div class="sidebar-section-title">الرئيسية</div>

                <a href="<?php echo e(route('admin.dashboard')); ?>"
                   class="sidebar-link <?php echo e(request()->routeIs('admin.dashboard') || request()->routeIs('admin.home') ? 'active' : ''); ?>">
                    <span>لوحة المؤشرات</span>
                </a>

                <a href="<?php echo e(route('admin.surveys.index')); ?>"
                   class="sidebar-link <?php echo e(request()->routeIs('admin.surveys.*') ? 'active' : ''); ?>">
                    <span>الاستبيانات</span>
                </a>
                <a href="<?php echo e(route('admin.templates.index')); ?>"
                    class="sidebar-link <?php echo e(request()->routeIs('admin.templates.*') ? 'active' : ''); ?>">
                        <span>قوالب الاستبيانات</span>
                </a>
            </div>

            <div class="sidebar-section">
                <div class="sidebar-section-title">الهيكل الأكاديمي</div>

                <a href="<?php echo e(route('admin.academic.faculties.index')); ?>"
                   class="sidebar-link <?php echo e(request()->routeIs('admin.academic.faculties.*') ? 'active' : ''); ?>">
                    <span>الكليات</span>
                </a>

                <a href="<?php echo e(route('admin.academic.departments.index')); ?>"
                   class="sidebar-link <?php echo e(request()->routeIs('admin.academic.departments.*') ? 'active' : ''); ?>">
                    <span>الأقسام</span>
                </a>

                <a href="<?php echo e(route('admin.academic.courses.index')); ?>"
                   class="sidebar-link <?php echo e(request()->routeIs('admin.academic.courses.*') ? 'active' : ''); ?>">
                    <span>المقررات</span>
                </a>

                <a href="<?php echo e(route('admin.academic.offerings.index')); ?>"
                   class="sidebar-link <?php echo e(request()->routeIs('admin.academic.offerings.*') ? 'active' : ''); ?>">
                    <span>المواد المسجلة</span>
                </a>
            </div>

            <div class="sidebar-section sidebar-bottom">
                <div class="sidebar-section-title">الحساب</div>

                <?php if(auth()->guard()->check()): ?>
                    <div class="sidebar-user-card">
                        <div class="sidebar-user-name"><?php echo e(auth()->user()->name); ?></div>
                        <div class="sidebar-user-email"><?php echo e(auth()->user()->email); ?></div>
                    </div>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="sidebar-link sidebar-link-button">
                        <span>تسجيل الخروج</span>
                    </button>
                </form>
            </div>
        </aside>

        <main class="admin-main">
            <header class="admin-topbar">
                <div class="topbar-left">
                    <button class="sidebar-toggle" id="sidebarToggle">☰</button>

                    <div class="topbar-title-wrap">
                        <h1><?php echo e($pageTitle ?? 'لوحة التحكم'); ?></h1>
                        <p><?php echo e($pageSubtitle ?? 'إدارة النظام ومتابعة البيانات'); ?></p>
                    </div>
                </div>

                <div class="topbar-right">
                    <?php if(auth()->guard()->check()): ?>
                        <div class="topbar-user-badge">
                            <?php echo e(auth()->user()->name); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </header>

            <section class="admin-content">
                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul style="margin:0; padding-right:18px;">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <?php echo $__env->yieldContent('content'); ?>
            </section>
        </main>
    </div>

    <script>
        const sidebar = document.getElementById('adminSidebar');
        const overlay = document.getElementById('adminOverlay');
        const toggle = document.getElementById('sidebarToggle');

        function openSidebar() {
            sidebar.classList.add('open');
            overlay.classList.add('show');
        }

        function closeSidebar() {
            sidebar.classList.remove('open');
            overlay.classList.remove('show');
        }

        if (toggle) {
            toggle.addEventListener('click', openSidebar);
        }

        if (overlay) {
            overlay.addEventListener('click', closeSidebar);
        }
    </script>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH /Users/monanashaat/Projects/university-survey/resources/views/layouts/admin.blade.php ENDPATH**/ ?>