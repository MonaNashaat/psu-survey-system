@extends('layouts.admin')

@php
    $pageTitle = 'إنشاء استبيان جديد';
    $pageSubtitle = 'إضافة استبيان جديد مع إمكانية استخدام قالب جاهز';
@endphp

@section('content')
    @php
        $departmentsJson = $departments->map(function ($department) {
            return [
                'id' => $department->id,
                'name_ar' => $department->name_ar,
                'faculty_id' => $department->faculty_id,
            ];
        })->values();

        $coursesJson = $courses->map(function ($course) {
            return [
                'id' => $course->id,
                'name_ar' => $course->name_ar,
                'code' => $course->code,
                'department_id' => $course->department_id,
            ];
        })->values();

        $offeringsJson = $courseOfferings->map(function ($offering) {
            return [
                'id' => $offering->id,
                'course_id' => $offering->course_id,
                'academic_year' => $offering->academic_year,
                'semester' => $offering->semester,
                'level' => $offering->level,
                'instructor_name' => $offering->instructor_name,
                'assistant_name' => $offering->assistant_name,
            ];
        })->values();

        $templatesJson = $templates->map(function ($template) {
            return [
                'id' => $template->id,
                'name' => $template->name,
                'scope_level' => $template->scope_level,
                'faculty_id' => $template->faculty_id,
                'department_id' => $template->department_id,
            ];
        })->values();

        $currentUser = auth()->user();
        $isUniversityAdmin = $currentUser->isUniversityAdmin();
        $isFacultyAdmin = $currentUser->isFacultyAdmin();
        $isDepartmentAdmin = $currentUser->isDepartmentAdmin();

        $defaultScopeLevel = old(
            'scope_level',
            $isDepartmentAdmin ? 'department' : ($isFacultyAdmin ? 'faculty' : 'faculty')
        );
    @endphp

    <div class="page-actions">
        <a href="{{ route('admin.surveys.index') }}" class="btn btn-secondary">رجوع إلى الاستبيانات</a>
        <a href="{{ route('admin.templates.index') }}" class="btn btn-secondary">قوالب الاستبيانات</a>
    </div>

    <div class="card">
        <div class="card-body">
            <form method="POST" action="{{ route('admin.surveys.store') }}">
                @csrf

                <div class="grid-2">
                    <div class="form-group">
                        <label class="form-label">عنوان الاستبيان</label>
                        <input type="text" name="title" value="{{ old('title') }}">
                    </div>

                    <div class="form-group">
                        <label class="form-label">نوع الاستبيان</label>
                        <select name="survey_scope" id="survey_scope">
                            <option value="general" {{ old('survey_scope', 'general') == 'general' ? 'selected' : '' }}>استبيان عام</option>
                            <option value="course" {{ old('survey_scope') == 'course' ? 'selected' : '' }}>استبيان مرتبط بمادة</option>
                        </select>
                    </div>
                </div>

                <div class="grid-2">
                    @if($isUniversityAdmin)
                        <div class="form-group">
                            <label class="form-label">مستوى الاستبيان</label>
                            <select name="scope_level" id="scope_level">
                                <option value="university" {{ $defaultScopeLevel === 'university' ? 'selected' : '' }}>على مستوى الجامعة</option>
                                <option value="faculty" {{ $defaultScopeLevel === 'faculty' ? 'selected' : '' }}>على مستوى الكلية</option>
                                <option value="department" {{ $defaultScopeLevel === 'department' ? 'selected' : '' }}>على مستوى القسم</option>
                            </select>
                        </div>

                        <div class="form-group" id="survey-faculty-wrapper">
                            <label class="form-label">الكلية</label>
                            <select name="faculty_id" id="survey_faculty_id">
                                <option value="">اختر الكلية</option>
                                @foreach($faculties as $faculty)
                                    <option value="{{ $faculty->id }}" {{ old('faculty_id') == $faculty->id ? 'selected' : '' }}>
                                        {{ $faculty->name_ar }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                    @elseif($isFacultyAdmin)
                        <input type="hidden" name="scope_level" id="scope_level" value="{{ $defaultScopeLevel === 'department' ? 'department' : 'faculty' }}">
                        <input type="hidden" name="faculty_id" id="survey_faculty_id" value="{{ $currentUser->faculty_id }}">

                        <div class="form-group">
                            <label class="form-label">مستوى الاستبيان</label>
                            <select id="scope_level_display">
                                <option value="faculty" {{ $defaultScopeLevel === 'faculty' ? 'selected' : '' }}>على مستوى الكلية</option>
                                <option value="department" {{ $defaultScopeLevel === 'department' ? 'selected' : '' }}>على مستوى القسم</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label">الكلية</label>
                            <input type="text" value="{{ $faculties->first()?->name_ar }}" disabled>
                        </div>
                    @else
                        <input type="hidden" name="scope_level" id="scope_level" value="department">
                        <input type="hidden" name="faculty_id" id="survey_faculty_id" value="{{ $currentUser->faculty_id }}">
                        <input type="hidden" name="department_id" id="survey_department_id" value="{{ $currentUser->department_id }}">

                        <div class="form-group">
                            <label class="form-label">مستوى الاستبيان</label>
                            <input type="text" value="على مستوى القسم" disabled>
                        </div>

                        <div class="form-group">
                            <label class="form-label">القسم</label>
                            <input type="text" value="{{ $departments->first()?->name_ar }}" disabled>
                        </div>
                    @endif
                </div>

                @if(!$isDepartmentAdmin)
                    <div class="grid-2">
                        <div class="form-group" id="survey-department-wrapper">
                            <label class="form-label">القسم</label>
                            <select name="department_id" id="survey_department_id">
                                <option value="">اختر القسم</option>
                                @foreach($departments as $department)
                                    <option value="{{ $department->id }}"
                                            data-faculty-id="{{ $department->faculty_id }}"
                                            {{ old('department_id') == $department->id ? 'selected' : '' }}>
                                        {{ $department->name_ar }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                @endif

                <div class="grid-2">
                    <div class="form-group">
                        <label class="form-label">استخدام قالب جاهز</label>
                        <select name="template_id" id="template_id">
                            <option value="">إنشاء استبيان بدون قالب</option>
                        </select>
                        <small style="display:block; margin-top:8px; color:#6b7280;">
                            سيتم عرض القوالب المناسبة حسب مستوى الاستبيان والكلية والقسم.
                        </small>
                    </div>
                </div>

                <div id="course-offering-wrapper">
                    <div class="grid-2">
                        <div class="form-group">
                            <label class="form-label">الكلية</label>
                            <select id="faculty_id">
                                <option value="">اختر الكلية</option>
                                @foreach($faculties as $faculty)
                                    <option value="{{ $faculty->id }}">{{ $faculty->name_ar }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label">القسم الأكاديمي للمقرر</label>
                            <select id="department_id">
                                <option value="">اختر القسم</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label">المقرر</label>
                            <select id="course_id">
                                <option value="">اختر المقرر</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label">المادة المسجلة</label>
                            <select name="course_offering_id" id="course_offering_id">
                                <option value="">اختر المادة المسجلة</option>
                            </select>
                        </div>
                    </div>

                    <div id="offering-preview" class="card" style="display:none; margin-bottom:16px; background:#f8f9ff; border-color:#d9def7;">
                        <div class="card-body" id="offering-preview-content"></div>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">وصف الاستبيان</label>
                    <textarea name="description">{{ old('description') }}</textarea>
                </div>

                <div class="grid-2">
                    <div class="form-group">
                        <label class="form-label">عدد الردود المتوقع</label>
                        <input type="number" name="expected_responses" min="1" value="{{ old('expected_responses') }}" placeholder="مثال: 100">
                    </div>

                    <div class="checkbox-row" style="margin-top: 32px;">
                        <input type="checkbox" id="auto_close_on_limit" name="auto_close_on_limit" {{ old('auto_close_on_limit', true) ? 'checked' : '' }}>
                        <label for="auto_close_on_limit" style="margin:0;">إغلاق الاستبيان تلقائيًا عند الوصول إلى العدد المطلوب</label>
                    </div>
                </div>

                <div class="checkbox-row">
                    <input type="checkbox" id="is_active" name="is_active" {{ old('is_active', true) ? 'checked' : '' }}>
                    <label for="is_active" style="margin:0;">تفعيل الاستبيان</label>
                </div>

                <div class="checkbox-row">
                    <input type="checkbox" id="allow_multiple_submissions" name="allow_multiple_submissions" {{ old('allow_multiple_submissions') ? 'checked' : '' }}>
                    <label for="allow_multiple_submissions" style="margin:0;">السماح بأكثر من رد من نفس الجهاز</label>
                </div>

                <div id="manual-builder-wrapper">
                    <hr style="margin:24px 0; border:none; border-top:1px solid #e4e8f0;">

                    <div class="page-actions" style="justify-content:space-between; align-items:center;">
                        <h2 class="section-title" style="margin:0;">المحاور والأسئلة</h2>
                        <button type="button" class="btn btn-primary" onclick="addSection()">إضافة محور</button>
                    </div>

                    <div id="sections-wrapper"></div>

                    <hr style="margin:24px 0; border:none; border-top:1px solid #e4e8f0;">

                    <div class="form-group">
                        <label class="form-label">سؤال التعليقات الإضافية</label>
                        <input type="text" name="comments_question" value="{{ old('comments_question', 'تعليقات أخرى') }}">
                    </div>
                </div>

                <div class="page-actions">
                    <button type="submit" class="btn btn-primary">حفظ الاستبيان</button>
                    <a href="{{ route('admin.surveys.index') }}" class="btn btn-secondary">إلغاء</a>
                </div>
            </form>
        </div>
    </div>
@endsection

@push('styles')
<style>
    .section-box,
    .question-box {
        border: 1px solid #e4e8f0;
        border-radius: 16px;
        padding: 16px;
        margin-bottom: 16px;
        background: #fafbff;
    }

    .section-title-inline {
        margin-bottom: 12px;
        font-size: 18px;
        font-weight: 800;
        color: #28335f;
    }

    .option-input {
        margin-bottom: 8px;
    }
</style>
@endpush

@push('scripts')
<script>
    let sectionIndex = 0;

    function addSection() {
        const wrapper = document.getElementById('sections-wrapper');

        const html = `
            <div class="section-box" id="section-${sectionIndex}">
                <div class="section-title-inline">محور جديد</div>

                <div class="form-group">
                    <label class="form-label">عنوان المحور</label>
                    <input type="text" name="sections[${sectionIndex}][title]">
                </div>

                <div id="questions-wrapper-${sectionIndex}"></div>

                <div class="page-actions">
                    <button type="button" class="btn btn-primary" onclick="addQuestion(${sectionIndex})">إضافة سؤال</button>
                    <button type="button" class="btn btn-danger" onclick="removeElement('section-${sectionIndex}')">حذف المحور</button>
                </div>
            </div>
        `;

        wrapper.insertAdjacentHTML('beforeend', html);
        sectionIndex++;
    }

    function addQuestion(sectionIdx) {
        const wrapper = document.getElementById(`questions-wrapper-${sectionIdx}`);
        const questionCount = wrapper.querySelectorAll('.question-box').length;

        const html = `
            <div class="question-box" id="section-${sectionIdx}-question-${questionCount}">
                <div class="form-group">
                    <label class="form-label">نص السؤال</label>
                    <textarea name="sections[${sectionIdx}][questions][${questionCount}][question_text]"></textarea>
                </div>

                <div class="form-group">
                    <label class="form-label">نوع السؤال</label>
                    <select name="sections[${sectionIdx}][questions][${questionCount}][type]" onchange="toggleOptions(this, ${sectionIdx}, ${questionCount})">
                        <option value="scale">تقييم 1-5</option>
                        <option value="mcq">اختيار من متعدد</option>
                        <option value="text">نص مفتوح</option>
                    </select>
                </div>

                <div class="checkbox-row">
                    <input type="checkbox" id="required-${sectionIdx}-${questionCount}" name="sections[${sectionIdx}][questions][${questionCount}][is_required]" checked>
                    <label for="required-${sectionIdx}-${questionCount}" style="margin:0;">سؤال إجباري</label>
                </div>

                <div class="form-group options-box" id="options-box-${sectionIdx}-${questionCount}">
                    <label class="form-label">الخيارات</label>
                    <div class="option-input">
                        <input type="text" name="sections[${sectionIdx}][questions][${questionCount}][options][]" value="غير موافق بشدة">
                    </div>
                    <div class="option-input">
                        <input type="text" name="sections[${sectionIdx}][questions][${questionCount}][options][]" value="غير موافق">
                    </div>
                    <div class="option-input">
                        <input type="text" name="sections[${sectionIdx}][questions][${questionCount}][options][]" value="محايد">
                    </div>
                    <div class="option-input">
                        <input type="text" name="sections[${sectionIdx}][questions][${questionCount}][options][]" value="أوافق">
                    </div>
                    <div class="option-input">
                        <input type="text" name="sections[${sectionIdx}][questions][${questionCount}][options][]" value="أوافق بشدة">
                    </div>
                </div>

                <div class="page-actions">
                    <button type="button" class="btn btn-danger" onclick="removeElement('section-${sectionIdx}-question-${questionCount}')">حذف السؤال</button>
                </div>
            </div>
        `;

        wrapper.insertAdjacentHTML('beforeend', html);
    }

    function toggleOptions(selectEl, sectionIdx, questionIdx) {
        const box = document.getElementById(`options-box-${sectionIdx}-${questionIdx}`);
        box.style.display = selectEl.value === 'text' ? 'none' : 'block';
    }

    function removeElement(id) {
        const el = document.getElementById(id);
        if (el) el.remove();
    }
</script>

<script>
    const departmentsData = @json($departmentsJson);
    const coursesData = @json($coursesJson);
    const offeringsData = @json($offeringsJson);
    const templatesData = @json($templatesJson);

    const oldTemplateId = @json(old('template_id'));
    const oldScopeLevel = @json($defaultScopeLevel);

    const semesterLabels = {
        first: 'الفصل الدراسي الأول',
        second: 'الفصل الدراسي الثاني',
        summer: 'الفصل الصيفي',
    };

    const facultySelect = document.getElementById('faculty_id');
    const departmentSelect = document.getElementById('department_id');
    const courseSelect = document.getElementById('course_id');
    const offeringSelect = document.getElementById('course_offering_id');
    const offeringPreview = document.getElementById('offering-preview');
    const offeringPreviewContent = document.getElementById('offering-preview-content');

    const surveyScopeSelect = document.getElementById('survey_scope');
    const courseOfferingWrapper = document.getElementById('course-offering-wrapper');

    const scopeLevelSelect = document.getElementById('scope_level');
    const scopeLevelDisplaySelect = document.getElementById('scope_level_display');
    const surveyFacultySelect = document.getElementById('survey_faculty_id');
    const surveyDepartmentSelect = document.getElementById('survey_department_id');
    const surveyFacultyWrapper = document.getElementById('survey-faculty-wrapper');
    const surveyDepartmentWrapper = document.getElementById('survey-department-wrapper');

    const templateSelect = document.getElementById('template_id');
    const manualBuilderWrapper = document.getElementById('manual-builder-wrapper');

    function getCurrentScopeLevel() {
        if (scopeLevelSelect) return scopeLevelSelect.value;
        if (scopeLevelDisplaySelect) return scopeLevelDisplaySelect.value;
        return 'faculty';
    }

    function setHiddenScopeLevel(value) {
        if (scopeLevelSelect) {
            scopeLevelSelect.value = value;
        }
    }

    function resetSelect(select, placeholder) {
        select.innerHTML = `<option value="">${placeholder}</option>`;
    }

    function populateDepartments() {
        resetSelect(departmentSelect, 'اختر القسم');
        resetSelect(courseSelect, 'اختر المقرر');
        resetSelect(offeringSelect, 'اختر المادة المسجلة');
        offeringPreview.style.display = 'none';
        offeringPreviewContent.innerHTML = '';

        const facultyId = facultySelect.value;
        if (!facultyId) return;

        const filteredDepartments = departmentsData.filter(
            department => String(department.faculty_id) === String(facultyId)
        );

        filteredDepartments.forEach(department => {
            const option = document.createElement('option');
            option.value = department.id;
            option.textContent = department.name_ar;
            departmentSelect.appendChild(option);
        });
    }

    function populateCourses() {
        resetSelect(courseSelect, 'اختر المقرر');
        resetSelect(offeringSelect, 'اختر المادة المسجلة');
        offeringPreview.style.display = 'none';
        offeringPreviewContent.innerHTML = '';

        const departmentId = departmentSelect.value;
        if (!departmentId) return;

        const filteredCourses = coursesData.filter(
            course => String(course.department_id) === String(departmentId)
        );

        filteredCourses.forEach(course => {
            const option = document.createElement('option');
            option.value = course.id;
            option.textContent = `${course.name_ar}${course.code ? ' - ' + course.code : ''}`;
            courseSelect.appendChild(option);
        });
    }

    function populateOfferings() {
        resetSelect(offeringSelect, 'اختر المادة المسجلة');
        offeringPreview.style.display = 'none';
        offeringPreviewContent.innerHTML = '';

        const courseId = courseSelect.value;
        if (!courseId) return;

        const filteredOfferings = offeringsData.filter(
            offering => String(offering.course_id) === String(courseId)
        );

        filteredOfferings.forEach(offering => {
            const option = document.createElement('option');
            option.value = offering.id;
            option.textContent = `${offering.academic_year} - ${semesterLabels[offering.semester] ?? offering.semester} - ${offering.level}`;
            offeringSelect.appendChild(option);
        });
    }

    function showOfferingPreview() {
        offeringPreview.style.display = 'none';
        offeringPreviewContent.innerHTML = '';

        const selectedOfferingId = offeringSelect.value;
        if (!selectedOfferingId) return;

        const selectedOffering = offeringsData.find(
            offering => String(offering.id) === String(selectedOfferingId)
        );

        if (!selectedOffering) return;

        offeringPreviewContent.innerHTML = `
            <strong>بيانات المادة المسجلة:</strong><br>
            العام الدراسي: ${selectedOffering.academic_year}<br>
            الفصل الدراسي: ${semesterLabels[selectedOffering.semester] ?? selectedOffering.semester}<br>
            الفرقة: ${selectedOffering.level}<br>
            القائم على التدريس: ${selectedOffering.instructor_name ?? '-'}<br>
            الهيئة المعاونة: ${selectedOffering.assistant_name ?? '-'}
        `;
        offeringPreview.style.display = 'block';
    }

    function toggleSurveyScope() {
        if (surveyScopeSelect.value === 'course') {
            courseOfferingWrapper.style.display = 'block';
        } else {
            courseOfferingWrapper.style.display = 'none';

            facultySelect.value = '';
            resetSelect(departmentSelect, 'اختر القسم');
            resetSelect(courseSelect, 'اختر المقرر');
            resetSelect(offeringSelect, 'اختر المادة المسجلة');
            offeringPreview.style.display = 'none';
            offeringPreviewContent.innerHTML = '';
        }
    }

    function populateSurveyDepartments() {
        if (!surveyDepartmentSelect || !surveyFacultySelect) return;

        const selectedFacultyId = surveyFacultySelect.value;
        const oldSelectedValue = surveyDepartmentSelect.getAttribute('data-old-value') || surveyDepartmentSelect.value;

        resetSelect(surveyDepartmentSelect, 'اختر القسم');

        if (!selectedFacultyId) return;

        const filteredDepartments = departmentsData.filter(
            department => String(department.faculty_id) === String(selectedFacultyId)
        );

        filteredDepartments.forEach(department => {
            const option = document.createElement('option');
            option.value = department.id;
            option.textContent = department.name_ar;

            if (String(oldSelectedValue) === String(department.id)) {
                option.selected = true;
            }

            surveyDepartmentSelect.appendChild(option);
        });
    }

    function toggleScopeFields() {
        const currentScope = getCurrentScopeLevel();

        if (surveyFacultyWrapper) {
            surveyFacultyWrapper.style.display = currentScope === 'faculty' || currentScope === 'department' ? 'block' : 'none';
        }

        if (surveyDepartmentWrapper) {
            surveyDepartmentWrapper.style.display = currentScope === 'department' ? 'block' : 'none';
        }

        if (currentScope === 'university') {
            if (surveyFacultySelect) surveyFacultySelect.value = '';
            if (surveyDepartmentSelect) {
                surveyDepartmentSelect.value = '';
                surveyDepartmentSelect.setAttribute('data-old-value', '');
            }
        }

        if (currentScope === 'faculty') {
            if (surveyDepartmentSelect) {
                surveyDepartmentSelect.value = '';
                surveyDepartmentSelect.setAttribute('data-old-value', '');
            }
        }

        populateTemplates();
    }

    function populateTemplates() {
        if (!templateSelect) return;

        const currentScope = getCurrentScopeLevel();
        const selectedFacultyId = surveyFacultySelect ? surveyFacultySelect.value : null;
        const selectedDepartmentId = surveyDepartmentSelect ? surveyDepartmentSelect.value : null;
        const currentValue = templateSelect.value || oldTemplateId || '';

        templateSelect.innerHTML = '<option value="">إنشاء استبيان بدون قالب</option>';

        const filteredTemplates = templatesData.filter(template => {
            if (template.scope_level !== currentScope) {
                return false;
            }

            if (currentScope === 'faculty') {
                if (!selectedFacultyId) return false;
                return String(template.faculty_id) === String(selectedFacultyId);
            }

            if (currentScope === 'department') {
                if (!selectedDepartmentId) return false;
                return String(template.department_id) === String(selectedDepartmentId);
            }

            return true;
        });

        filteredTemplates.forEach(template => {
            const option = document.createElement('option');
            option.value = template.id;
            option.textContent = template.name;

            if (String(currentValue) === String(template.id)) {
                option.selected = true;
            }

            templateSelect.appendChild(option);
        });

        toggleTemplateMode();
    }

    function toggleTemplateMode() {
        if (!templateSelect || !manualBuilderWrapper) return;

        if (templateSelect.value) {
            manualBuilderWrapper.style.display = 'none';
        } else {
            manualBuilderWrapper.style.display = 'block';

            if (!document.getElementById('sections-wrapper').children.length) {
                addSection();
            }
        }
    }

    facultySelect?.addEventListener('change', populateDepartments);
    departmentSelect?.addEventListener('change', populateCourses);
    courseSelect?.addEventListener('change', populateOfferings);
    offeringSelect?.addEventListener('change', showOfferingPreview);

    surveyScopeSelect?.addEventListener('change', toggleSurveyScope);

    scopeLevelDisplaySelect?.addEventListener('change', function () {
        setHiddenScopeLevel(this.value);
        toggleScopeFields();
    });

    scopeLevelSelect?.addEventListener('change', toggleScopeFields);

    surveyFacultySelect?.addEventListener('change', function () {
        populateSurveyDepartments();
        populateTemplates();
    });

    surveyDepartmentSelect?.addEventListener('change', function () {
        this.setAttribute('data-old-value', this.value);
        populateTemplates();
    });

    templateSelect?.addEventListener('change', toggleTemplateMode);

    if (scopeLevelSelect && oldScopeLevel) {
        scopeLevelSelect.value = oldScopeLevel;
    }

    if (scopeLevelDisplaySelect && oldScopeLevel) {
        scopeLevelDisplaySelect.value = oldScopeLevel === 'university' ? 'faculty' : oldScopeLevel;
        setHiddenScopeLevel(scopeLevelDisplaySelect.value);
    }

    if (surveyDepartmentSelect) {
        surveyDepartmentSelect.setAttribute('data-old-value', @json(old('department_id')));
    }

    populateSurveyDepartments();
    toggleSurveyScope();
    toggleScopeFields();
    populateTemplates();

    if (!templateSelect.value && !document.getElementById('sections-wrapper').children.length) {
        addSection();
    }
</script>
@endpush