@extends('layouts.admin')

@php
    $pageTitle = 'إدارة الأقسام';
    $pageSubtitle = 'إضافة وعرض الأقسام وربطها بالكليات';
@endphp

@section('content')
    <div class="page-actions">
        <a href="{{ route('admin.academic.faculties.index') }}" class="btn btn-secondary">الكليات</a>
        <a href="{{ route('admin.academic.courses.index') }}" class="btn btn-secondary">المقررات</a>
        <a href="{{ route('admin.academic.offerings.index') }}" class="btn btn-secondary">المواد المسجلة</a>
    </div>

    <div class="grid-2">
        <div class="card">
            <div class="card-body">
                <h2 class="section-title">إضافة قسم جديد</h2>

                <form method="POST" action="{{ route('admin.academic.departments.store') }}">
                    @csrf

                    <div class="form-group">
                        <label class="form-label">الكلية</label>
                        <select name="faculty_id" required>
                            <option value="">اختر الكلية</option>
                            @foreach($faculties as $faculty)
                                <option value="{{ $faculty->id }}" {{ old('faculty_id') == $faculty->id ? 'selected' : '' }}>
                                    {{ $faculty->name_ar }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">اسم القسم بالعربية</label>
                        <input type="text" name="name_ar" value="{{ old('name_ar') }}" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">اسم القسم بالإنجليزية</label>
                        <input type="text" name="name_en" value="{{ old('name_en') }}">
                    </div>

                    <button type="submit" class="btn btn-primary">إضافة القسم</button>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <h2 class="section-title">ملخص سريع</h2>

                <div class="grid-2">
                    <div class="card stats-card">
                        <div class="stats-title">عدد الأقسام</div>
                        <div class="stats-value">{{ $departments->count() }}</div>
                    </div>

                    <div class="card stats-card">
                        <div class="stats-title">عدد الكليات</div>
                        <div class="stats-value">{{ $faculties->count() }}</div>
                    </div>
                </div>

                <div style="height: 12px;"></div>

                <div class="card stats-card">
                    <div class="stats-title">آخر قسم مضاف</div>
                    <div class="stats-value" style="font-size:18px;">
                        {{ $departments->first()?->name_ar ?? '—' }}
                    </div>
                    <div class="stats-note">
                        {{ $departments->first()?->faculty?->name_ar ?? '' }}
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div style="height: 16px;"></div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>الكلية</th>
                    <th>اسم القسم بالعربية</th>
                    <th>اسم القسم بالإنجليزية</th>
                </tr>
            </thead>
            <tbody>
                @forelse($departments as $department)
                    <tr>
                        <td>{{ $department->id }}</td>
                        <td>{{ $department->faculty?->name_ar ?? '—' }}</td>
                        <td>{{ $department->name_ar }}</td>
                        <td>{{ $department->name_en ?: '—' }}</td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="4">
                            <div class="empty-state">لا توجد أقسام حتى الآن</div>
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
@endsection