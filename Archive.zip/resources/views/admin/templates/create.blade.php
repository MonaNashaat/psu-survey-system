@extends('layouts.admin')

@php
    $pageTitle = 'إنشاء قالب جديد';
    $pageSubtitle = 'بناء قالب استبيان يمكن استخدامه لاحقًا';
@endphp

@section('content')
    @php
        $currentUser = auth()->user();
        $isUniversityAdmin = $currentUser->isUniversityAdmin();
        $isFacultyAdmin = $currentUser->isFacultyAdmin();
        $isDepartmentAdmin = $currentUser->isDepartmentAdmin();

        $defaultScopeLevel = old(
            'scope_level',
            $isDepartmentAdmin ? 'department' : ($isFacultyAdmin ? 'faculty' : 'faculty')
        );

        $departmentsJson = $departments->map(function ($department) {
            return [
                'id' => $department->id,
                'name_ar' => $department->name_ar,
                'faculty_id' => $department->faculty_id,
            ];
        })->values();
    @endphp

    <div class="page-actions">
        <a href="{{ route('admin.templates.index') }}" class="btn btn-secondary">الرجوع إلى القوالب</a>
    </div>

    <div class="card">
        <div class="card-body">
            <form method="POST" action="{{ route('admin.templates.store') }}">
                @csrf

                <div class="grid-2">
                    <div class="form-group">
                        <label class="form-label">اسم القالب</label>
                        <input type="text" name="name" value="{{ old('name') }}">
                    </div>

                    <div class="checkbox-row" style="margin-top: 32px;">
                        <input type="checkbox" id="is_active" name="is_active" {{ old('is_active', true) ? 'checked' : '' }}>
                        <label for="is_active" style="margin:0;">تفعيل القالب</label>
                    </div>
                </div>

                <div class="grid-2">
                    @if($isUniversityAdmin)
                        <div class="form-group">
                            <label class="form-label">مستوى القالب</label>
                            <select name="scope_level" id="scope_level">
                                <option value="university" {{ $defaultScopeLevel === 'university' ? 'selected' : '' }}>على مستوى الجامعة</option>
                                <option value="faculty" {{ $defaultScopeLevel === 'faculty' ? 'selected' : '' }}>على مستوى الكلية</option>
                                <option value="department" {{ $defaultScopeLevel === 'department' ? 'selected' : '' }}>على مستوى القسم</option>
                            </select>
                        </div>

                        <div class="form-group" id="faculty-wrapper">
                            <label class="form-label">الكلية</label>
                            <select name="faculty_id" id="faculty_id">
                                <option value="">اختر الكلية</option>
                                @foreach($faculties as $faculty)
                                    <option value="{{ $faculty->id }}" {{ old('faculty_id') == $faculty->id ? 'selected' : '' }}>
                                        {{ $faculty->name_ar }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                    @elseif($isFacultyAdmin)
                        <input type="hidden" name="scope_level" id="scope_level" value="{{ $defaultScopeLevel === 'department' ? 'department' : 'faculty' }}">
                        <input type="hidden" name="faculty_id" id="faculty_id" value="{{ $currentUser->faculty_id }}">

                        <div class="form-group">
                            <label class="form-label">مستوى القالب</label>
                            <select id="scope_level_display">
                                <option value="faculty" {{ $defaultScopeLevel === 'faculty' ? 'selected' : '' }}>على مستوى الكلية</option>
                                <option value="department" {{ $defaultScopeLevel === 'department' ? 'selected' : '' }}>على مستوى القسم</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label">الكلية</label>
                            <input type="text" value="{{ $faculties->first()?->name_ar }}" disabled>
                        </div>
                    @else
                        <input type="hidden" name="scope_level" id="scope_level" value="department">
                        <input type="hidden" name="faculty_id" id="faculty_id" value="{{ $currentUser->faculty_id }}">
                        <input type="hidden" name="department_id" id="department_id" value="{{ $currentUser->department_id }}">

                        <div class="form-group">
                            <label class="form-label">مستوى القالب</label>
                            <input type="text" value="على مستوى القسم" disabled>
                        </div>

                        <div class="form-group">
                            <label class="form-label">القسم</label>
                            <input type="text" value="{{ $departments->first()?->name_ar }}" disabled>
                        </div>
                    @endif
                </div>

                @if(!$isDepartmentAdmin)
                    <div class="grid-2">
                        <div class="form-group" id="department-wrapper">
                            <label class="form-label">القسم</label>
                            <select name="department_id" id="department_select">
                                <option value="">اختر القسم</option>
                                @foreach($departments as $department)
                                    <option value="{{ $department->id }}"
                                            data-faculty-id="{{ $department->faculty_id }}"
                                            {{ old('department_id') == $department->id ? 'selected' : '' }}>
                                        {{ $department->name_ar }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                @endif

                <div class="form-group">
                    <label class="form-label">وصف القالب</label>
                    <textarea name="description">{{ old('description') }}</textarea>
                </div>

                <hr style="margin:24px 0; border:none; border-top:1px solid #e4e8f0;">

                <div class="page-actions" style="justify-content:space-between; align-items:center;">
                    <h2 class="section-title" style="margin:0;">المحاور والأسئلة</h2>
                    <button type="button" class="btn btn-primary" onclick="addSection()">إضافة محور</button>
                </div>

                <div id="sections-wrapper"></div>

                <hr style="margin:24px 0; border:none; border-top:1px solid #e4e8f0;">

                <div class="form-group">
                    <label class="form-label">سؤال التعليقات الإضافية</label>
                    <input type="text" name="comments_question" value="{{ old('comments_question', 'تعليقات أخرى') }}">
                </div>

                <div class="page-actions">
                    <button type="submit" class="btn btn-primary">حفظ القالب</button>
                    <a href="{{ route('admin.templates.index') }}" class="btn btn-secondary">إلغاء</a>
                </div>
            </form>
        </div>
    </div>
@endsection

@push('styles')
<style>
    .section-box,
    .question-box {
        border: 1px solid #e4e8f0;
        border-radius: 16px;
        padding: 16px;
        margin-bottom: 16px;
        background: #fafbff;
    }

    .section-title-inline {
        margin-bottom: 12px;
        font-size: 18px;
        font-weight: 800;
        color: #28335f;
    }

    .option-input {
        margin-bottom: 8px;
    }
</style>
@endpush

@push('scripts')
<script>
    let sectionIndex = 0;

    function addSection() {
        const wrapper = document.getElementById('sections-wrapper');

        const html = `
            <div class="section-box" id="section-${sectionIndex}">
                <div class="section-title-inline">محور جديد</div>

                <div class="form-group">
                    <label class="form-label">عنوان المحور</label>
                    <input type="text" name="sections[${sectionIndex}][title]">
                </div>

                <div id="questions-wrapper-${sectionIndex}"></div>

                <div class="page-actions">
                    <button type="button" class="btn btn-primary" onclick="addQuestion(${sectionIndex})">إضافة سؤال</button>
                    <button type="button" class="btn btn-danger" onclick="removeElement('section-${sectionIndex}')">حذف المحور</button>
                </div>
            </div>
        `;

        wrapper.insertAdjacentHTML('beforeend', html);
        sectionIndex++;
    }

    function addQuestion(sectionIdx) {
        const wrapper = document.getElementById(`questions-wrapper-${sectionIdx}`);
        const questionCount = wrapper.querySelectorAll('.question-box').length;

        const html = `
            <div class="question-box" id="section-${sectionIdx}-question-${questionCount}">
                <div class="form-group">
                    <label class="form-label">نص السؤال</label>
                    <textarea name="sections[${sectionIdx}][questions][${questionCount}][question_text]"></textarea>
                </div>

                <div class="form-group">
                    <label class="form-label">نوع السؤال</label>
                    <select name="sections[${sectionIdx}][questions][${questionCount}][type]" onchange="toggleOptions(this, ${sectionIdx}, ${questionCount})">
                        <option value="scale">تقييم 1-5</option>
                        <option value="mcq">اختيار من متعدد</option>
                        <option value="text">نص مفتوح</option>
                    </select>
                </div>

                <div class="checkbox-row">
                    <input type="checkbox" id="required-${sectionIdx}-${questionCount}" name="sections[${sectionIdx}][questions][${questionCount}][is_required]" checked>
                    <label for="required-${sectionIdx}-${questionCount}" style="margin:0;">سؤال إجباري</label>
                </div>

                <div class="form-group options-box" id="options-box-${sectionIdx}-${questionCount}">
                    <label class="form-label">الخيارات</label>
                    <div class="option-input"><input type="text" name="sections[${sectionIdx}][questions][${questionCount}][options][]" value="غير موافق بشدة"></div>
                    <div class="option-input"><input type="text" name="sections[${sectionIdx}][questions][${questionCount}][options][]" value="غير موافق"></div>
                    <div class="option-input"><input type="text" name="sections[${sectionIdx}][questions][${questionCount}][options][]" value="محايد"></div>
                    <div class="option-input"><input type="text" name="sections[${sectionIdx}][questions][${questionCount}][options][]" value="أوافق"></div>
                    <div class="option-input"><input type="text" name="sections[${sectionIdx}][questions][${questionCount}][options][]" value="أوافق بشدة"></div>
                </div>

                <div class="page-actions">
                    <button type="button" class="btn btn-danger" onclick="removeElement('section-${sectionIdx}-question-${questionCount}')">حذف السؤال</button>
                </div>
            </div>
        `;

        wrapper.insertAdjacentHTML('beforeend', html);
    }

    function toggleOptions(selectEl, sectionIdx, questionIdx) {
        const box = document.getElementById(`options-box-${sectionIdx}-${questionIdx}`);
        box.style.display = selectEl.value === 'text' ? 'none' : 'block';
    }

    function removeElement(id) {
        const el = document.getElementById(id);
        if (el) el.remove();
    }

    addSection();
</script>

<script>
    const departmentsData = @json($departmentsJson);
    const scopeLevelSelect = document.getElementById('scope_level');
    const scopeLevelDisplaySelect = document.getElementById('scope_level_display');
    const facultySelect = document.getElementById('faculty_id');
    const departmentSelect = document.getElementById('department_select');
    const facultyWrapper = document.getElementById('faculty-wrapper');
    const departmentWrapper = document.getElementById('department-wrapper');

    function getCurrentScopeLevel() {
        if (scopeLevelSelect) return scopeLevelSelect.value;
        if (scopeLevelDisplaySelect) return scopeLevelDisplaySelect.value;
        return 'faculty';
    }

    function setHiddenScopeLevel(value) {
        if (scopeLevelSelect) {
            scopeLevelSelect.value = value;
        }
    }

    function resetSelect(select, placeholder) {
        if (!select) return;
        select.innerHTML = `<option value="">${placeholder}</option>`;
    }

    function populateDepartments() {
        if (!departmentSelect || !facultySelect) return;

        const selectedFacultyId = facultySelect.value;
        const oldDepartmentId = @json(old('department_id'));

        resetSelect(departmentSelect, 'اختر القسم');

        if (!selectedFacultyId) return;

        const filteredDepartments = departmentsData.filter(
            department => String(department.faculty_id) === String(selectedFacultyId)
        );

        filteredDepartments.forEach(department => {
            const option = document.createElement('option');
            option.value = department.id;
            option.textContent = department.name_ar;

            if (String(oldDepartmentId) === String(department.id)) {
                option.selected = true;
            }

            departmentSelect.appendChild(option);
        });
    }

    function toggleScopeFields() {
        const currentScope = getCurrentScopeLevel();

        if (facultyWrapper) {
            facultyWrapper.style.display = currentScope === 'faculty' || currentScope === 'department' ? 'block' : 'none';
        }

        if (departmentWrapper) {
            departmentWrapper.style.display = currentScope === 'department' ? 'block' : 'none';
        }

        if (currentScope === 'university') {
            if (facultySelect) facultySelect.value = '';
            if (departmentSelect) resetSelect(departmentSelect, 'اختر القسم');
        }

        if (currentScope === 'faculty') {
            if (departmentSelect) resetSelect(departmentSelect, 'اختر القسم');
        }

        if (currentScope === 'department') {
            populateDepartments();
        }
    }

    scopeLevelDisplaySelect?.addEventListener('change', function () {
        setHiddenScopeLevel(this.value);
        toggleScopeFields();
    });

    scopeLevelSelect?.addEventListener('change', toggleScopeFields);
    facultySelect?.addEventListener('change', populateDepartments);

    if (scopeLevelDisplaySelect) {
        scopeLevelDisplaySelect.value = @json($defaultScopeLevel === 'university' ? 'faculty' : $defaultScopeLevel);
        setHiddenScopeLevel(scopeLevelDisplaySelect.value);
    }

    toggleScopeFields();
</script>
@endpush