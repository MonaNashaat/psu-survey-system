<?php

use App\Http\Controllers\Admin\AcademicStructureController;
use App\Http\Controllers\Admin\SurveyAdminController;
use App\Http\Controllers\SurveyController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\SurveyTemplateController;

Route::get('/', function () {
    if (Auth::check()) {
        return redirect()->route('admin.dashboard');
    }

    return redirect()->route('login');
})->name('home');

Route::get('/dashboard', function () {
    return redirect()->route('admin.dashboard');
})->middleware(['auth'])->name('dashboard');

/*
|--------------------------------------------------------------------------
| Public Survey Routes
|--------------------------------------------------------------------------
*/

Route::get('/surveys/{id}', [SurveyController::class, 'show'])->name('surveys.show');
Route::post('/surveys/{id}/submit', [SurveyController::class, 'submit'])->name('surveys.submit');
Route::get('/survey-thank-you', [SurveyController::class, 'thankyou'])->name('surveys.thankyou');

/*
|--------------------------------------------------------------------------
| Admin Routes
|--------------------------------------------------------------------------
*/

Route::prefix('admin')->name('admin.')->middleware(['auth'])->group(function () {
    Route::get('/', [SurveyAdminController::class, 'dashboard'])->name('home');
    Route::get('/dashboard', [SurveyAdminController::class, 'dashboard'])->name('dashboard');

    // accessible after login
    Route::get('/surveys', [SurveyAdminController::class, 'index'])->name('surveys.index');

    Route::middleware(['survey.results.access'])->group(function () {
        Route::get('/surveys/{survey}/results', [SurveyAdminController::class, 'results'])->name('surveys.results');
        Route::get('/surveys/{survey}/export/excel', [SurveyAdminController::class, 'exportExcel'])->name('surveys.export.excel');
        Route::get('/surveys/{survey}/export/pdf', [SurveyAdminController::class, 'exportPdf'])->name('surveys.export.pdf');
    });

    Route::middleware(['role:admin'])->group(function () {
        // IMPORTANT: create/store must come before {survey}
        Route::get('/surveys/create', [SurveyAdminController::class, 'create'])->name('surveys.create');
        Route::post('/surveys', [SurveyAdminController::class, 'store'])->name('surveys.store');

        Route::get('/surveys/{survey}', [SurveyAdminController::class, 'show'])->name('surveys.show');
        Route::get('/surveys/{survey}/edit', [SurveyAdminController::class, 'edit'])->name('surveys.edit');
        Route::put('/surveys/{survey}', [SurveyAdminController::class, 'update'])->name('surveys.update');
        Route::delete('/surveys/{survey}', [SurveyAdminController::class, 'destroy'])->name('surveys.destroy');

        Route::get('/surveys/{survey}/permissions', [SurveyAdminController::class, 'permissions'])->name('surveys.permissions');
        Route::post('/surveys/{survey}/permissions', [SurveyAdminController::class, 'storePermission'])->name('surveys.permissions.store');
        Route::delete('/surveys/{survey}/permissions/{permission}', [SurveyAdminController::class, 'destroyPermission'])->name('surveys.permissions.destroy');

        Route::prefix('templates')->name('templates.')->group(function () {
            Route::get('/', [SurveyTemplateController::class, 'index'])->name('index');
            Route::get('/create', [SurveyTemplateController::class, 'create'])->name('create');
            Route::post('/', [SurveyTemplateController::class, 'store'])->name('store');
            Route::get('/{template}/edit', [SurveyTemplateController::class, 'edit'])->name('edit');
            Route::put('/{template}', [SurveyTemplateController::class, 'update'])->name('update');
            Route::delete('/{template}', [SurveyTemplateController::class, 'destroy'])->name('destroy');
        });

        Route::prefix('academic')->name('academic.')->group(function () {
            Route::get('/faculties', [AcademicStructureController::class, 'facultiesIndex'])->name('faculties.index');
            Route::post('/faculties', [AcademicStructureController::class, 'facultiesStore'])->name('faculties.store');

            Route::get('/departments', [AcademicStructureController::class, 'departmentsIndex'])->name('departments.index');
            Route::post('/departments', [AcademicStructureController::class, 'departmentsStore'])->name('departments.store');

            Route::get('/courses', [AcademicStructureController::class, 'coursesIndex'])->name('courses.index');
            Route::post('/courses', [AcademicStructureController::class, 'coursesStore'])->name('courses.store');

            Route::get('/offerings', [AcademicStructureController::class, 'offeringsIndex'])->name('offerings.index');
            Route::post('/offerings', [AcademicStructureController::class, 'offeringsStore'])->name('offerings.store');
        });
    });
});

require __DIR__ . '/auth.php';