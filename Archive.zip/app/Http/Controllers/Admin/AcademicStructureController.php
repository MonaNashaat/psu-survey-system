<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Course;
use App\Models\CourseOffering;
use App\Models\Department;
use App\Models\Faculty;
use Illuminate\Http\Request;

class AcademicStructureController extends Controller
{
    public function facultiesIndex()
    {
        $faculties = Faculty::latest()->get();

        return view('admin.academic.faculties.index', compact('faculties'));
    }

    public function facultiesStore(Request $request)
    {
        $request->validate([
            'name_ar' => 'required|string|max:255',
            'name_en' => 'nullable|string|max:255',
        ]);

        Faculty::create([
            'name_ar' => $request->name_ar,
            'name_en' => $request->name_en,
        ]);

        return redirect()->route('admin.academic.faculties.index')
            ->with('success', 'تم إضافة الكلية بنجاح');
    }

    public function departmentsIndex()
    {
        $departments = Department::with('faculty')->latest()->get();
        $faculties = Faculty::orderBy('name_ar')->get();

        return view('admin.academic.departments.index', compact('departments', 'faculties'));
    }

    public function departmentsStore(Request $request)
    {
        $request->validate([
            'faculty_id' => 'required|exists:faculties,id',
            'name_ar' => 'required|string|max:255',
            'name_en' => 'nullable|string|max:255',
        ]);

        Department::create([
            'faculty_id' => $request->faculty_id,
            'name_ar' => $request->name_ar,
            'name_en' => $request->name_en,
        ]);

        return redirect()->route('admin.academic.departments.index')
            ->with('success', 'تم إضافة القسم بنجاح');
    }

    public function coursesIndex()
    {
        $courses = Course::with('department.faculty')->latest()->get();
        $departments = Department::with('faculty')->orderBy('name_ar')->get();

        return view('admin.academic.courses.index', compact('courses', 'departments'));
    }

    public function coursesStore(Request $request)
    {
        $request->validate([
            'department_id' => 'required|exists:departments,id',
            'code' => 'nullable|string|max:255',
            'name_ar' => 'required|string|max:255',
            'name_en' => 'nullable|string|max:255',
        ]);

        Course::create([
            'department_id' => $request->department_id,
            'code' => $request->code,
            'name_ar' => $request->name_ar,
            'name_en' => $request->name_en,
        ]);

        return redirect()->route('admin.academic.courses.index')
            ->with('success', 'تم إضافة المقرر بنجاح');
    }

    public function offeringsIndex()
    {
        $offerings = CourseOffering::with('course.department.faculty')->latest()->get();
        $courses = Course::with('department.faculty')->orderBy('name_ar')->get();

        return view('admin.academic.offerings.index', compact('offerings', 'courses'));
    }

    public function offeringsStore(Request $request)
    {
        $request->validate([
            'course_id' => 'required|exists:courses,id',
            'academic_year' => 'required|string|max:255',
            'semester' => 'required|in:first,second,summer',
            'level' => 'required|string|max:255',
            'instructor_name' => 'nullable|string|max:255',
            'assistant_name' => 'nullable|string|max:255',
        ]);

        CourseOffering::create([
            'course_id' => $request->course_id,
            'academic_year' => $request->academic_year,
            'semester' => $request->semester,
            'level' => $request->level,
            'instructor_name' => $request->instructor_name,
            'assistant_name' => $request->assistant_name,
        ]);

        return redirect()->route('admin.academic.offerings.index')
            ->with('success', 'تم إضافة الطرح الدراسي بنجاح');
    }
}