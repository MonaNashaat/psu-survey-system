<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class AdminUsersSeeder extends Seeder
{
    public function run(): void
    {
        User::firstOrCreate(
            ['email' => 'admin@eng.psu.edu.eg'],
            [
                'name' => 'System Admin',
                'password' => Hash::make('123456'),
                'role' => 'admin',
            ]
        );

        User::firstOrCreate(
            ['email' => 'qac@eng.psu.edu.eg'],
            [
                'name' => 'Quality User',
                'password' => Hash::make('123456'),
                'role' => 'quality',
            ]
        );
    }
}